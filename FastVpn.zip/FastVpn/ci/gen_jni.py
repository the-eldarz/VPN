"""Читает таблицу JNINativeMethod из исходников hev-socks5-tunnel и генерирует
Java-класс со статическими native-методами с точно такими же сигнатурами."""
import glob, os, re, sys

src_root, out_root = sys.argv[1], sys.argv[2]
text = ""
for p in glob.glob(os.path.join(src_root, "**", "*.c"), recursive=True):
    t = open(p, errors="ignore").read()
    if "JNINativeMethod" in t:
        text = t
        print("JNI source:", p)
        break

m = re.search(r'"([A-Za-z0-9_$/]*TProxyService)"', text)
cls = m.group(1) if m and "/" in m.group(1) else "hev/htproxy/TProxyService"
methods = re.findall(r'\{\s*"(\w+)"\s*,\s*"([^"]+)"', text)
if not methods:
    methods = [("TProxyStartService", "(Ljava/lang/String;I)V"),
               ("TProxyStopService", "()V"),
               ("TProxyGetStats", "()[J")]
print("class:", cls)
print("methods:", methods)

PRIM = {'Z': 'boolean', 'B': 'byte', 'C': 'char', 'S': 'short', 'I': 'int',
        'J': 'long', 'F': 'float', 'D': 'double', 'V': 'void'}

def one(s, i):
    dims = 0
    while s[i] == '[':
        dims += 1; i += 1
    if s[i] == 'L':
        j = s.index(';', i)
        t = s[i + 1:j].replace('/', '.'); i = j + 1
    else:
        t = PRIM[s[i]]; i += 1
    return t + '[]' * dims, i

def conv(sig):
    args, ret = re.match(r'\((.*)\)(.*)', sig).groups()
    params, i = [], 0
    while i < len(args):
        t, i = one(args, i); params.append(t)
    return params, one(ret, 0)[0]

pkg = cls.rsplit('/', 1)[0].replace('/', '.')
name = cls.rsplit('/', 1)[1]
lines = [f"package {pkg};", "", f"public class {name} {{",
         '    static { System.loadLibrary("hev-socks5-tunnel"); }']
for n, sig in methods:
    ps, r = conv(sig)
    plist = ", ".join(f"{t} a{k}" for k, t in enumerate(ps))
    lines.append(f"    public static native {r} {n}({plist});")
lines.append("}")
d = os.path.join(out_root, os.path.dirname(cls))
os.makedirs(d, exist_ok=True)
open(os.path.join(d, name + ".java"), "w").write("\n".join(lines) + "\n")
print("\n".join(lines))
open(os.path.join(out_root, "PKG.txt"), "w").write(pkg)
