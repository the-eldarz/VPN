"""Скачивает базу «IP -> страна» (ip-location-db, IPv4), сливает соседние диапазоны и пишет бинарный файл:
записи по 10 байт: start(u32) end(u32) cc(2 байта ASCII), отсортированы по start."""
import struct, sys, urllib.request

out = sys.argv[1]
URLS = [
    "https://cdn.jsdelivr.net/npm/@ip-location-db/geo-whois-asn-country/geo-whois-asn-country-ipv4-num.csv",
    "https://cdn.jsdelivr.net/npm/@ip-location-db/asn-country/asn-country-ipv4-num.csv",
    "https://cdn.jsdelivr.net/npm/@ip-location-db/dbip-country/dbip-country-ipv4-num.csv",
    "https://raw.githubusercontent.com/sapics/ip-location-db/main/geo-whois-asn-country/geo-whois-asn-country-ipv4-num.csv",
]
text = None
for u in URLS:
    try:
        print("GeoIP:", u)
        text = urllib.request.urlopen(u, timeout=90).read().decode("utf-8", "ignore")
        if text.count("\n") > 1000:
            break
        text = None
    except Exception as e:
        print("  не удалось:", e)

rows = []
if text:
    for line in text.splitlines():
        p = line.strip().split(",")
        if len(p) < 3 or not p[0].isdigit() or not p[1].isdigit():
            continue
        cc = p[2].strip().upper()
        if len(cc) != 2:
            continue
        rows.append((int(p[0]), int(p[1]), cc))
rows.sort()
merged = []
for s, e, cc in rows:
    if merged and merged[-1][2] == cc and s == merged[-1][1] + 1:
        merged[-1][1] = e
    else:
        merged.append([s, e, cc])
with open(out, "wb") as f:
    for s, e, cc in merged:
        f.write(struct.pack(">II2s", s, e, cc.encode()))
print("GeoIP ranges:", len(merged))
