#!/usr/bin/env bash
set -euxo pipefail
cd "$(dirname "$0")/.."
ROOT="$PWD"
export ANDROID_NDK_HOME="${ANDROID_NDK_HOME:-${ANDROID_NDK_LATEST_HOME:-${ANDROID_NDK_ROOT:-}}}"
echo "NDK: $ANDROID_NDK_HOME"
mkdir -p app/libs app/src/main/jniLibs/arm64-v8a app/src/main/java/gen

# ---------- 1. Ядро Xray -> fastcore.aar ----------
cd core
[ -f go.mod ] || go mod init fastcoremod
go get github.com/xtls/xray-core@latest
go mod tidy
go get golang.org/x/mobile/bind
go install golang.org/x/mobile/cmd/gomobile@latest
export PATH="$PATH:$(go env GOPATH)/bin"
gomobile init
gomobile bind -v -target=android/arm64 -androidapi 24 -ldflags="-s -w" -o "$ROOT/app/libs/fastcore.aar" ./fastcore
cd "$ROOT"

# ---------- 2. tun2socks (hev-socks5-tunnel) -> .so ----------
HEV=/tmp/hev
rm -rf "$HEV"; mkdir -p "$HEV/jni"
echo 'include $(call all-subdir-makefiles)' > "$HEV/jni/Android.mk"
git clone --recursive --depth 1 --shallow-submodules https://github.com/heiher/hev-socks5-tunnel "$HEV/jni/hev-socks5-tunnel"
(cd "$HEV" && "$ANDROID_NDK_HOME/ndk-build" NDK_PROJECT_PATH=. APP_ABI=arm64-v8a APP_PLATFORM=android-24 -j4)
cp "$HEV/libs/arm64-v8a/libhev-socks5-tunnel.so" app/src/main/jniLibs/arm64-v8a/

# Java-класс JNI с сигнатурами, прочитанными прямо из исходников hev
rm -rf app/src/main/java/gen
mkdir -p app/src/main/java/gen
python3 ci/gen_jni.py "$HEV/jni/hev-socks5-tunnel/src" app/src/main/java/gen
PKG=$(cat app/src/main/java/gen/PKG.txt); rm app/src/main/java/gen/PKG.txt
cat > app/src/main/java/gen/TunBridge.kt <<KT
package app.fastvpn

object TunBridge {
    fun start(path: String, fd: Int) { $PKG.TProxyService.TProxyStartService(path, fd) }
    fun stop() { $PKG.TProxyService.TProxyStopService() }
}
KT

# Умеет ли tun2socks авторизацию на SOCKS5 (защита локального порта)
if grep -rqE '"username"' "$HEV/jni/hev-socks5-tunnel/src/"; then HEVAUTH=true; else HEVAUTH=false; fi
echo "hev socks5 auth support: $HEVAUTH"
cat > app/src/main/java/gen/HevCaps.kt <<KT
package app.fastvpn

object HevCaps { const val AUTH = $HEVAUTH }
KT

# ---------- 2b. База стран по IP (для флагов) ----------
mkdir -p app/src/main/assets
python3 ci/build_geo.py app/src/main/assets/geo4.bin || : > app/src/main/assets/geo4.bin
ls -la app/src/main/assets

# ---------- 3. APK ----------
gradle assembleRelease --no-daemon
