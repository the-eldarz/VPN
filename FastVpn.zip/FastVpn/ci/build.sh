#!/usr/bin/env bash
set -euxo pipefail
cd "$(dirname "$0")/.."
ROOT="$PWD"
export ANDROID_NDK_HOME="${ANDROID_NDK_HOME:-${ANDROID_NDK_LATEST_HOME:-${ANDROID_NDK_ROOT:-}}}"
echo "NDK: $ANDROID_NDK_HOME"
mkdir -p app/libs app/src/main/jniLibs/arm64-v8a app/src/main/java/gen

# ---------- 1. Ядро Xray -> fastcore.aar ----------
cd core
[ -f go.mod ] || go mod init fastcoremod
go get github.com/xtls/xray-core@latest
go mod tidy
go get golang.org/x/mobile/bind
go install golang.org/x/mobile/cmd/gomobile@latest
export PATH="$PATH:$(go env GOPATH)/bin"
gomobile init
gomobile bind -v -target=android/arm64 -androidapi 24 -ldflags="-s -w" -o "$ROOT/app/libs/fastcore.aar" ./fastcore
cd "$ROOT"

# ---------- 2. tun2socks (hev-socks5-tunnel) -> .so ----------
HEV=/tmp/hev
rm -rf "$HEV"; mkdir -p "$HEV/jni"
echo 'include $(call all-subdir-makefiles)' > "$HEV/jni/Android.mk"
git clone --recursive --depth 1 --shallow-submodules https://github.com/heiher/hev-socks5-tunnel "$HEV/jni/hev-socks5-tunnel"
(cd "$HEV" && "$ANDROID_NDK_HOME/ndk-build" NDK_PROJECT_PATH=. APP_ABI=arm64-v8a APP_PLATFORM=android-24 -j4)
cp "$HEV/libs/arm64-v8a/libhev-socks5-tunnel.so" app/src/main/jniLibs/arm64-v8a/

# Kotlin-обёртка с правильным именем JNI-класса
CLS=$(grep -rhoE '"[A-Za-z0-9_$/]*TProxyService"' "$HEV/jni/hev-socks5-tunnel/src/" 2>/dev/null | head -1 | tr -d '"' || true)
[ -n "$CLS" ] || CLS=hev/htproxy/TProxyService
PKG=$(dirname "$CLS" | tr / .)
echo "JNI class: $CLS"
DIR="app/src/main/java/gen/$(dirname "$CLS")"
mkdir -p "$DIR"
cat > "$DIR/TProxyService.kt" <<KT
package $PKG

class TProxyService {
    companion object {
        init { System.loadLibrary("hev-socks5-tunnel") }
        @JvmStatic external fun TProxyStartService(configPath: String, fd: Int)
        @JvmStatic external fun TProxyStopService()
        @JvmStatic external fun TProxyGetStats(): LongArray
    }
}
KT
cat > app/src/main/java/gen/TunBridge.kt <<KT
package app.fastvpn

object TunBridge {
    fun start(path: String, fd: Int) = $PKG.TProxyService.TProxyStartService(path, fd)
    fun stop() = $PKG.TProxyService.TProxyStopService()
}
KT

# ---------- 3. APK ----------
gradle assembleRelease --no-daemon
