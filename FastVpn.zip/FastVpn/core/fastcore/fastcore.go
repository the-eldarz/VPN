package fastcore

import (
	"strings"
	"sync"

	"github.com/xtls/xray-core/core"
	"github.com/xtls/xray-core/infra/conf/serial"
	_ "github.com/xtls/xray-core/main/distro/all"
)

var (
	mu   sync.Mutex
	inst *core.Instance
)

// Start запускает Xray с JSON-конфигом.
func Start(config string) error {
	mu.Lock()
	defer mu.Unlock()
	if inst != nil {
		inst.Close()
		inst = nil
	}
	cfg, err := serial.LoadJSONConfig(strings.NewReader(config))
	if err != nil {
		return err
	}
	i, err := core.New(cfg)
	if err != nil {
		return err
	}
	if err := i.Start(); err != nil {
		return err
	}
	inst = i
	return nil
}

// Stop останавливает Xray.
func Stop() {
	mu.Lock()
	defer mu.Unlock()
	if inst != nil {
		inst.Close()
		inst = nil
	}
}

func Version() string { return core.Version() }
