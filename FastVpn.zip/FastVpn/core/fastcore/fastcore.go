package fastcore

import (
	"context"
	"fmt"
	"net"
	"net/http"
	"strings"
	"sync"
	"time"

	xnet "github.com/xtls/xray-core/common/net"
	"github.com/xtls/xray-core/core"
	"github.com/xtls/xray-core/infra/conf/serial"
	_ "github.com/xtls/xray-core/main/distro/all"
)

var (
	mu   sync.Mutex
	inst *core.Instance
)

// Start запускает Xray с JSON-конфигом.
func Start(config string) error {
	mu.Lock()
	defer mu.Unlock()
	if inst != nil {
		inst.Close()
		inst = nil
	}
	cfg, err := serial.LoadJSONConfig(strings.NewReader(config))
	if err != nil {
		return err
	}
	i, err := core.New(cfg)
	if err != nil {
		return err
	}
	if err := i.Start(); err != nil {
		return err
	}
	inst = i
	return nil
}

// Stop останавливает Xray.
func Stop() {
	mu.Lock()
	defer mu.Unlock()
	if inst != nil {
		inst.Close()
		inst = nil
	}
}

func Version() string { return core.Version() }

// Measure поднимает отдельный экземпляр Xray с этим конфигом (без входящих),
// делает HTTP-запрос через прокси и возвращает задержку в мс.
func Measure(config string, url string, timeoutSec int64) (int64, error) {
	cfg, err := serial.LoadJSONConfig(strings.NewReader(config))
	if err != nil {
		return 0, err
	}
	i, err := core.New(cfg)
	if err != nil {
		return 0, err
	}
	if err := i.Start(); err != nil {
		return 0, err
	}
	defer i.Close()
	tr := &http.Transport{
		DisableKeepAlives: true,
		DialContext: func(ctx context.Context, network, addr string) (net.Conn, error) {
			dest, err := xnet.ParseDestination(fmt.Sprintf("%s:%s", network, addr))
			if err != nil {
				return nil, err
			}
			return core.Dial(ctx, i, dest)
		},
	}
	client := &http.Client{Transport: tr, Timeout: time.Duration(timeoutSec) * time.Second}
	start := time.Now()
	resp, err := client.Get(url)
	if err != nil {
		return 0, err
	}
	resp.Body.Close()
	return time.Since(start).Milliseconds(), nil
}
