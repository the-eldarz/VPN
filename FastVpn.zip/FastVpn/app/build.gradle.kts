plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "app.fastvpn"
    compileSdk = 34
    defaultConfig {
        applicationId = "app.fastvpn"
        minSdk = 24
        targetSdk = 33
        versionCode = 9
        versionName = "0.9"
        ndk { abiFilters += listOf("arm64-v8a") }
    }
    signingConfigs {
        create("main") {
            storeFile = file("release.jks")
            storePassword = "4749a4eff75d6abdb4aa4228"
            keyAlias = "fastvpn"
            keyPassword = "4749a4eff75d6abdb4aa4228"
        }
    }
    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("main")
            isMinifyEnabled = false
        }
    }
    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    packaging { jniLibs.useLegacyPackaging = true }
}
dependencies {
    implementation(fileTree("libs") { include("*.aar") })
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
