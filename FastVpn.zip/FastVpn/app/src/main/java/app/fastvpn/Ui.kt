package app.fastvpn

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.widget.RemoteViews

/** Обновляет виджет и плитку быстрых настроек после смены состояния VPN. */
object Ui {
    fun refresh(ctx: Context) {
        val c = ctx.applicationContext
        runCatching { FastVpnWidget.refresh(c) }
        runCatching { TileService.requestListeningState(c, ComponentName(c, FastVpnTile::class.java)) }
    }
}

class FastVpnWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        for (id in ids) mgr.updateAppWidget(id, views(context))
    }

    companion object {
        fun views(ctx: Context): RemoteViews {
            val v = RemoteViews(ctx.packageName, R.layout.widget_vpn)
            val on = VpnState.running
            v.setTextViewText(R.id.widget_state, if (on) "Включён — нажмите, чтобы выключить" else "Выключен — нажмите, чтобы включить")
            v.setInt(R.id.widget_root, "setBackgroundResource", if (on) R.drawable.widget_bg_on else R.drawable.widget_bg_off)
            val i = Intent(ctx, ToggleActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            val pi = PendingIntent.getActivity(ctx, 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            v.setOnClickPendingIntent(R.id.widget_root, pi)
            return v
        }

        fun refresh(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, FastVpnWidget::class.java))
            if (ids.isNotEmpty()) mgr.updateAppWidget(ids, views(ctx))
        }
    }
}

class FastVpnTile : TileService() {
    override fun onStartListening() { update() }

    override fun onClick() {
        if (VpnState.running) {
            FastVpnService.stop(this)
        } else if (VpnService.prepare(this) != null) {
            val i = Intent(this, ToggleActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (Build.VERSION.SDK_INT >= 34) {
                startActivityAndCollapse(PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE))
            } else {
                @Suppress("DEPRECATION") startActivityAndCollapse(i)
            }
        } else {
            FastVpnService.startLast(this)
        }
        update()
    }

    private fun update() {
        val t = qsTile ?: return
        t.state = if (VpnState.running) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.label = "FastVpn"
        t.updateTile()
    }
}

/** Прозрачная активность: включает/выключает VPN (для виджета и плитки), при необходимости спрашивает разрешение. */
class ToggleActivity : android.app.Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (VpnState.running) {
            FastVpnService.stop(this); finish(); return
        }
        val i = VpnService.prepare(this)
        if (i != null) startActivityForResult(i, 1)
        else { FastVpnService.startLast(this); finish() }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (resultCode == RESULT_OK) FastVpnService.startLast(this)
        else VpnState.message = "Разрешение VPN не выдано"
        finish()
    }
}
