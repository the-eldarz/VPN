package app.fastvpn

import android.content.Context
import java.io.File

object Favorites {
    private fun f(ctx: Context) = File(ctx.applicationContext.filesDir, "favorites.txt")

    fun load(ctx: Context): List<Server> = try {
        f(ctx).readLines().mapNotNull { Parser.parseOne(it.trim()) }
    } catch (e: Exception) { emptyList() }

    fun save(ctx: Context, list: List<Server>) {
        try { f(ctx).writeText(list.joinToString("\n") { it.link }) } catch (_: Exception) { }
    }
}
