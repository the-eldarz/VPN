package app.fastvpn

import android.net.TrafficStats
import android.os.Process
import android.os.SystemClock
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

@Composable
fun Home(vm: MainViewModel, onStart: (Server) -> Unit, onStop: () -> Unit) {
    val connecting = vm.busy || vm.searching ||
        (!vm.connected && (VpnState.message == "Подключение…" || VpnState.message == "Подбор сервера…"))
    val state = if (vm.connected) 2 else if (connecting) 1 else 0
    val green = Color(0xFF2FA84F)
    val container by animateColorAsState(
        if (state == 2) green else Color(0xFF7B5CF0), tween(600), label = "container"
    )
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val stateScale by animateFloatAsState(
        if (state == 2) 1.05f else 1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy), label = "state"
    )
    val inf = rememberInfiniteTransition(label = "rings")
    val ring by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1600, easing = LinearEasing), RepeatMode.Restart), label = "ring")
    val title = if (vm.connected) (VpnState.serverName ?: vm.selected?.name) else vm.selected?.name

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(title ?: "Сервер не выбран", style = MaterialTheme.typography.titleMedium,
            maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
        Spacer(Modifier.height(16.dp))
        Box(Modifier.size(280.dp), contentAlignment = Alignment.Center) {
            if (state != 0) {
                repeat(2) { i ->
                    Box(
                        Modifier.size(200.dp)
                            .offset(y = (-6).dp)
                            .graphicsLayer {
                                val t = (ring + i * 0.5f) % 1f
                                scaleX = 1f + 0.45f * t
                                scaleY = 1f + 0.45f * t
                                alpha = (1f - t) * (if (state == 2) 0.22f else 0.45f)
                            }
                            .background(container, CircleShape)
                    )
                }
            }
            val label = TextStyle(
                fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color.White,
                shadow = Shadow(Color.Black.copy(alpha = 0.45f), Offset(0f, 3f), 6f)
            )
            Button3D(
                color = container,
                pressed = pressed,
                interactionSource = src,
                onClick = { vm.toggle(onStart, onStop) },
                modifier = Modifier.graphicsLayer { scaleX = stateScale; scaleY = stateScale }
            ) {
                Crossfade(targetState = state, label = "label") { st ->
                    when (st) {
                        1 -> CircularProgressIndicator(Modifier.size(48.dp), color = Color.White)
                        2 -> Text("СТОП", style = label)
                        else -> Text("СТАРТ", style = label)
                    }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Crossfade(targetState = vm.status, label = "status") { Text(it, textAlign = TextAlign.Center) }
        val notice = VpnState.notice
        if (vm.connected && notice != null) {
            Spacer(Modifier.height(4.dp))
            Text(notice, style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.tertiary, textAlign = TextAlign.Center)
        }
        AnimatedVisibility(visible = vm.connected) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Spacer(Modifier.height(8.dp))
                SessionInfo()
                Spacer(Modifier.height(12.dp))
                SpeedChart(VpnState.speed, Modifier.fillMaxWidth())
            }
        }
        Spacer(Modifier.height(32.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Автоподключение к самому быстрому", Modifier.weight(1f))
            Switch(checked = vm.auto, onCheckedChange = { vm.updateAuto(it) })
        }
    }
}

@Composable
fun SessionInfo() {
    var now by remember { mutableLongStateOf(SystemClock.elapsedRealtime()) }
    LaunchedEffect(Unit) { while (true) { now = SystemClock.elapsedRealtime(); delay(1000) } }
    val uid = Process.myUid()
    val rx = TrafficStats.getUidRxBytes(uid) - VpnState.baseRx
    val tx = TrafficStats.getUidTxBytes(uid) - VpnState.baseTx
    Text(
        "${fmtTime(now - VpnState.sessionStart)}  ·  ↓ ${fmtBytes(rx)}  ↑ ${fmtBytes(tx)}",
        style = MaterialTheme.typography.bodyMedium
    )
}

/** График скорости за последнюю минуту: зелёная — загрузка, фиолетовая — отправка. */
@Composable
fun SpeedChart(samples: List<SpeedSample>, modifier: Modifier = Modifier) {
    val down = Color(0xFF34C759)
    val up = Color(0xFFB39DFF)
    val last = samples.lastOrNull()
    Column(modifier) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("↓ ${fmtBytes((last?.rx ?: 0f).toLong())}/с", color = down, style = MaterialTheme.typography.bodyMedium)
            Text("↑ ${fmtBytes((last?.tx ?: 0f).toLong())}/с", color = up, style = MaterialTheme.typography.bodyMedium)
        }
        Canvas(Modifier.fillMaxWidth().height(80.dp)) {
            val n = 60
            val maxV = maxOf(samples.maxOfOrNull { maxOf(it.rx, it.tx) } ?: 0f, 20_000f)
            fun x(i: Int) = size.width * (i + (n - samples.size)).toFloat() / (n - 1)
            fun y(v: Float) = size.height * (1f - v / maxV)
            if (samples.size >= 2) {
                val pd = Path()
                val pu = Path()
                samples.forEachIndexed { i, s ->
                    if (i == 0) { pd.moveTo(x(i), y(s.rx)); pu.moveTo(x(i), y(s.tx)) }
                    else { pd.lineTo(x(i), y(s.rx)); pu.lineTo(x(i), y(s.tx)) }
                }
                val fill = Path()
                fill.addPath(pd)
                fill.lineTo(x(samples.size - 1), size.height)
                fill.lineTo(x(0), size.height)
                fill.close()
                drawPath(fill, Brush.verticalGradient(listOf(down.copy(alpha = 0.35f), Color.Transparent)))
                val st = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
                drawPath(pd, down, style = st)
                drawPath(pu, up, style = st)
            }
        }
    }
}

/** Объёмная круглая кнопка: боковая стенка, градиент, блик, фаска; при нажатии «вдавливается». */
@Composable
fun Button3D(
    color: Color,
    pressed: Boolean,
    interactionSource: MutableInteractionSource,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val depth = 12.dp
    val press by animateFloatAsState(if (pressed) 1f else 0f, tween(90), label = "sink")
    Box(
        modifier
            .size(width = 200.dp, height = 200.dp + depth)
            .clickable(interactionSource = interactionSource, indication = null, onClick = onClick)
            .drawBehind {
                val r = size.width / 2f
                val d = depth.toPx()
                val dark = lerp(color, Color.Black, 0.5f)
                val light = lerp(color, Color.White, 0.38f)
                val down = d * 0.85f * press
                val c = Offset(r, r + down)

                drawOval(
                    brush = Brush.radialGradient(
                        listOf(Color.Black.copy(alpha = 0.40f * (1f - 0.6f * press)), Color.Transparent),
                        center = Offset(r, 2 * r + d * 0.45f), radius = r * 0.95f
                    ),
                    topLeft = Offset(r * 0.08f, 2 * r - d * 0.3f),
                    size = Size(r * 1.84f, d * 2.4f)
                )
                drawCircle(
                    brush = Brush.verticalGradient(listOf(lerp(dark, color, 0.3f), dark), startY = r, endY = 2 * r + d),
                    radius = r, center = Offset(r, r + d)
                )
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(light, color, dark),
                        center = Offset(r * 0.8f, c.y - r * 0.55f), radius = r * 1.8f
                    ),
                    radius = r, center = c
                )
                drawCircle(
                    brush = Brush.verticalGradient(
                        listOf(Color.White.copy(alpha = 0.65f), Color.Transparent, Color.Black.copy(alpha = 0.40f)),
                        startY = c.y - r, endY = c.y + r
                    ),
                    radius = r - 2.dp.toPx(), center = c, style = Stroke(width = 4.dp.toPx())
                )
                val inner = r * 0.80f
                drawCircle(
                    brush = Brush.verticalGradient(
                        listOf(dark.copy(alpha = 0.55f), light.copy(alpha = 0.35f)),
                        startY = c.y - inner, endY = c.y + inner
                    ),
                    radius = inner, center = c
                )
                drawCircle(
                    brush = Brush.verticalGradient(
                        listOf(Color.Black.copy(alpha = 0.30f), Color.Transparent, Color.White.copy(alpha = 0.30f)),
                        startY = c.y - inner, endY = c.y + inner
                    ),
                    radius = inner, center = c, style = Stroke(width = 3.dp.toPx())
                )
                drawOval(
                    brush = Brush.verticalGradient(
                        listOf(Color.White.copy(alpha = 0.50f), Color.White.copy(alpha = 0.02f)),
                        startY = c.y - r * 0.95f, endY = c.y - r * 0.2f
                    ),
                    topLeft = Offset(c.x - r * 0.62f, c.y - r * 0.93f),
                    size = Size(r * 1.24f, r * 0.70f)
                )
            }
    ) {
        Box(
            Modifier.size(200.dp).offset { IntOffset(0, (press * depth.toPx() * 0.85f).roundToInt()) },
            contentAlignment = Alignment.Center
        ) { content() }
    }
}
