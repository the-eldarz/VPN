package app.fastvpn

import android.util.Base64
import org.json.JSONObject
import java.net.URLDecoder

object Parser {
    private val schemes = setOf("vless", "vmess", "trojan", "ss", "hysteria2", "hy2", "tuic")

    fun parseAll(text: String): List<Server> =
        decode(text.trim()).lineSequence().map { it.trim() }
            .mapNotNull { parseOne(it) }.distinctBy { it.link }.toList()

    private fun decode(t: String): String {
        if (t.contains("://")) return t
        return try {
            val s = t.filter { !it.isWhitespace() }.replace('-', '+').replace('_', '/')
            String(Base64.decode(s, Base64.DEFAULT))
        } catch (e: Exception) { t }
    }

    fun parseOne(line: String): Server? {
        val scheme = line.substringBefore("://", "").lowercase()
        if (scheme !in schemes) return null
        return try { if (scheme == "vmess") vmess(line) else generic(line) } catch (e: Exception) { null }
    }

    private fun generic(l: String): Server {
        val rest = l.substringAfter("://")
        val name = runCatching { URLDecoder.decode(rest.substringAfter('#', ""), "UTF-8") }.getOrDefault("")
        val auth = rest.substringBefore('#').substringBefore('?').substringBefore('/').substringAfterLast('@')
        val host: String
        val port: Int
        if (auth.startsWith("[")) {
            host = auth.substringBefore(']').drop(1)
            port = auth.substringAfter("]:").toInt()
        } else {
            host = auth.substringBeforeLast(':')
            port = auth.substringAfterLast(':').toInt()
        }
        return Server(l, name.ifBlank { host }, host, port)
    }

    private fun vmess(l: String): Server {
        val b64 = l.substringAfter("://").substringBefore('#').replace('-', '+').replace('_', '/')
        val o = JSONObject(String(Base64.decode(b64, Base64.DEFAULT)))
        val host = o.getString("add")
        return Server(l, o.optString("ps").ifBlank { host }, host, o.get("port").toString().toInt())
    }
}
