package app.fastvpn

import android.content.Context

/** Результат подбора: сервер, откуда он взят («Группа · подгруппа») и его задержка. */
data class Pick(val server: Server, val source: String, val ping: Int)

fun Pick.save(ctx: Context) {
    ctx.applicationContext.getSharedPreferences("s", 0).edit()
        .putString("sel", server.link).putString("selSrc", source).apply()
}

/** Выбор сервера для подключения: сохранённый или самый быстрый из выбранной группы (или всех). */
object Auto {
    suspend fun resolveTarget(ctx: Context): Server? {
        val p = ctx.applicationContext.getSharedPreferences("s", 0)
        if (!p.getBoolean("auto", false)) return p.getString("sel", null)?.let { Parser.parseOne(it) }
        val pick = fastest(ctx, p.getString("autoGroup", "all") ?: "all") ?: return null
        pick.save(ctx)
        return pick.server
    }

    /** groupId: "all", "fav" (избранное) или id группы. exclude — ссылка сервера, который пропустить. */
    suspend fun fastest(ctx: Context, groupId: String, exclude: String? = null): Pick? {
        val repo = Repo(ctx.applicationContext)
        val sources = HashMap<String, String>()
        val pool = ArrayList<Server>()
        if (groupId == "fav") {
            for (s in Favorites.load(ctx).shuffled().take(40)) { pool.add(s); sources.putIfAbsent(s.link, "Избранное") }
        } else {
            val all = groupId == "all" || Catalog.groups.none { it.id == groupId }
            val groups = if (all) Catalog.groups else Catalog.groups.filter { it.id == groupId }
            for (g in groups) {
                val discovered = if (g.repo != null) {
                    try { repo.discover(g) } catch (e: Exception) { emptyList() }
                } else emptyList()
                val subs = (g.subgroups + discovered).distinctBy { it.url }.shuffled().take(if (all) 2 else 4)
                for (sg in subs) {
                    val list = try { repo.load(sg) } catch (e: Exception) { emptyList() }
                    for (s in list.shuffled().take(if (all) 4 else 10)) {
                        pool.add(s)
                        sources.putIfAbsent(s.link, g.title + " · " + sg.title)
                    }
                }
            }
        }
        val best = repo.fastestPick(pool.filter { it.link != exclude }) ?: return null
        return Pick(best.first, sources[best.first.link] ?: "", best.second)
    }
}
