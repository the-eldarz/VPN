package app.fastvpn

import android.content.Context

/** Выбор сервера для подключения: сохранённый или самый быстрый из выбранной группы (или всех). */
object Auto {
    suspend fun resolveTarget(ctx: Context): Server? {
        val p = ctx.applicationContext.getSharedPreferences("s", 0)
        if (!p.getBoolean("auto", false)) return p.getString("sel", null)?.let { Parser.parseOne(it) }
        return fastest(ctx, p.getString("autoGroup", "all") ?: "all")
    }

    /** groupId: "all", "fav" (избранное) или id группы. exclude — ссылка сервера, который пропустить. */
    suspend fun fastest(ctx: Context, groupId: String, exclude: String? = null): Server? {
        val repo = Repo(ctx.applicationContext)
        val pool = ArrayList<Server>()
        if (groupId == "fav") {
            pool.addAll(Favorites.load(ctx).shuffled().take(40))
        } else {
            val all = groupId == "all"
            val groups = if (all) Catalog.groups else Catalog.groups.filter { it.id == groupId }
            for (g in groups) {
                val discovered = if (g.repo != null) {
                    try { repo.discover(g) } catch (e: Exception) { emptyList() }
                } else emptyList()
                val subs = (g.subgroups + discovered).distinctBy { it.url }.shuffled().take(if (all) 2 else 4)
                for (sg in subs) {
                    val list = try { repo.load(sg) } catch (e: Exception) { emptyList() }
                    pool.addAll(list.shuffled().take(if (all) 4 else 10))
                }
            }
        }
        return repo.fastest(pool.filter { it.link != exclude })
    }
}
