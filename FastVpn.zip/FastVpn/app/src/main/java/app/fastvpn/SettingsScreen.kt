package app.fastvpn

import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun RadioRow(text: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = onClick)
        Text(text)
    }
}

@Composable
fun SwitchRow(title: String, sub: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title)
            if (sub != null) Text(sub, style = MaterialTheme.typography.bodySmall)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun SettingsScreen(vm: MainViewModel) {
    var picker by remember { mutableStateOf(false) }
    if (picker) AppPicker(vm) { picker = false } else SettingsList(vm) { picker = true }
}

@Composable
fun SettingsList(vm: MainViewModel, onPickApps: () -> Unit) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    val totals = remember(tick, vm.connected) { Stats.totals(ctx) }
    val days = remember(tick, vm.connected) { Stats.days(ctx, 7) }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        item { Text("Тема", style = MaterialTheme.typography.titleMedium) }
        item { RadioRow("Системная (по умолчанию)", vm.theme == "system") { vm.updateTheme("system") } }
        item { RadioRow("Тёмная", vm.theme == "dark") { vm.updateTheme("dark") } }
        item { RadioRow("Светлая", vm.theme == "light") { vm.updateTheme("light") } }

        item { Spacer(Modifier.height(12.dp)) }
        item { Text("Подключение", style = MaterialTheme.typography.titleMedium) }
        item {
            SwitchRow(
                "Автопереподключение",
                "Если сервер перестал отвечать или сеть сменилась (Wi-Fi ↔ мобильная), приложение само подберёт новый быстрый сервер",
                vm.autoReconnect
            ) { vm.updateAutoReconnect(it) }
        }
        item {
            SwitchRow(
                "Блокировать трафик при обрыве VPN",
                "Если VPN не удаётся восстановить, интернет остаётся заблокированным и не идёт напрямую",
                vm.killSwitch
            ) { vm.updateKillSwitch(it) }
        }
        item {
            TextButton(onClick = {
                try { ctx.startActivity(Intent(Settings.ACTION_VPN_SETTINGS)) } catch (_: Exception) { }
            }) { Text("Системные настройки VPN") }
        }
        item {
            Text(
                "Чтобы защита работала и когда приложение закрыто, включите там для FastVpn " +
                    "«Постоянный VPN» и «Блокировать подключения без VPN».",
                style = MaterialTheme.typography.bodySmall
            )
        }

        item { Spacer(Modifier.height(12.dp)) }
        item { Text("Автоподключение: откуда брать серверы", style = MaterialTheme.typography.titleMedium) }
        item {
            Text(
                "Если переключатель на главном экране включён, приложение проверит серверы " +
                    "из выбранного источника и подключится к самому быстрому.",
                style = MaterialTheme.typography.bodySmall
            )
        }
        item { RadioRow("Все группы", vm.autoGroup == "all") { vm.updateAutoGroup("all") } }
        item { RadioRow("Избранное", vm.autoGroup == "fav") { vm.updateAutoGroup("fav") } }
        items(Catalog.groups, key = { it.id }) { g ->
            RadioRow(g.title, vm.autoGroup == g.id) { vm.updateAutoGroup(g.id) }
        }

        item { Spacer(Modifier.height(12.dp)) }
        item { Text("Приложения через VPN", style = MaterialTheme.typography.titleMedium) }
        item { RadioRow("Все приложения", vm.splitMode == "all") { vm.updateSplitMode("all") } }
        item { RadioRow("Только выбранные", vm.splitMode == "only") { vm.updateSplitMode("only") } }
        item { RadioRow("Все, кроме выбранных", vm.splitMode == "except") { vm.updateSplitMode("except") } }
        if (vm.splitMode != "all") {
            item {
                TextButton(onClick = onPickApps) { Text("Выбрать приложения (${vm.splitApps.size})") }
            }
        }
        item { Text("Изменение применяется при следующем подключении.", style = MaterialTheme.typography.bodySmall) }

        item { Spacer(Modifier.height(12.dp)) }
        item { Text("Автообновление списков серверов", style = MaterialTheme.typography.titleMedium) }
        item { RadioRow("Выключено", vm.refreshHours == 0) { vm.updateRefreshHours(0) } }
        item { RadioRow("Каждые 3 часа", vm.refreshHours == 3) { vm.updateRefreshHours(3) } }
        item { RadioRow("Каждые 6 часов", vm.refreshHours == 6) { vm.updateRefreshHours(6) } }
        item { RadioRow("Каждые 12 часов", vm.refreshHours == 12) { vm.updateRefreshHours(12) } }
        item { RadioRow("Раз в сутки", vm.refreshHours == 24) { vm.updateRefreshHours(24) } }
        item {
            SwitchRow("Только по Wi-Fi", "Списки большие, поэтому мобильный трафик по умолчанию не используется", vm.refreshWifiOnly) {
                vm.updateRefreshWifi(it)
            }
        }
        item {
            val last = if (vm.lastRefresh == 0L) "ещё не обновлялись"
            else SimpleDateFormat("dd.MM HH:mm", Locale.getDefault()).format(Date(vm.lastRefresh))
            Text("Последнее обновление: $last", style = MaterialTheme.typography.bodySmall)
        }
        item { TextButton(onClick = { vm.refreshNow() }, enabled = !vm.refreshing) { Text(if (vm.refreshing) "Обновляем…" else "Обновить сейчас") } }

        item { Spacer(Modifier.height(12.dp)) }
        item { Text("Статистика", style = MaterialTheme.typography.titleMedium) }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Подключений: ${totals.sessions}")
                    Text("Время в VPN: ${fmtTime(totals.ms)}")
                    Text("Скачано: ${fmtBytes(totals.rx)}")
                    Text("Отправлено: ${fmtBytes(totals.tx)}")
                }
            }
        }
        item { Text("Последние 7 дней", style = MaterialTheme.typography.titleSmall) }
        items(days) { d ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(d.day)
                Text("${fmtTime(d.ms)} · ↓ ${fmtBytes(d.rx)} ↑ ${fmtBytes(d.tx)}")
            }
        }
        item {
            Text(
                "Трафик считается по данным системы для приложения и включает шифрование, поэтому он приблизительный.",
                style = MaterialTheme.typography.bodySmall
            )
        }
        item { TextButton(onClick = { Stats.reset(ctx); tick++ }) { Text("Сбросить статистику") } }
    }
}

@Composable
fun AppPicker(vm: MainViewModel, onBack: () -> Unit) {
    BackHandler { onBack() }
    LaunchedEffect(Unit) { vm.loadApps() }
    var q by remember { mutableStateOf("") }
    val all = vm.apps
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) }
            Text(
                if (vm.splitMode == "only") "Только эти приложения" else "Все, кроме этих",
                style = MaterialTheme.typography.titleLarge
            )
        }
        OutlinedTextField(
            value = q, onValueChange = { q = it }, singleLine = true, label = { Text("Поиск") },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
        )
        if (all == null) {
            Row(Modifier.fillMaxWidth().padding(24.dp), horizontalArrangement = Arrangement.Center) {
                CircularProgressIndicator()
            }
        } else {
            val list = all.filter { q.isBlank() || it.label.contains(q, true) || it.pkg.contains(q, true) }
            LazyColumn(Modifier.fillMaxSize()) {
                items(list, key = { it.pkg }) { a ->
                    Row(
                        Modifier.fillMaxWidth().clickable { vm.toggleApp(a.pkg) }.padding(horizontal = 16.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(checked = a.pkg in vm.splitApps, onCheckedChange = { vm.toggleApp(a.pkg) })
                        a.icon?.let { Image(bitmap = it, contentDescription = null, modifier = Modifier.size(36.dp)) }
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(a.label, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(a.pkg, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        }
    }
}
