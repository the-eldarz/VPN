package app.fastvpn

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

object VpnState {
    var running by mutableStateOf(false)
    var message by mutableStateOf<String?>(null)
}
