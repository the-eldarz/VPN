package app.fastvpn

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

data class SpeedSample(val rx: Float, val tx: Float)

object VpnState {
    var running by mutableStateOf(false)
    var message by mutableStateOf<String?>(null)
    /** Подсказка поверх работающего VPN (например, «Переподключение…»). */
    var notice by mutableStateOf<String?>(null)
    var serverName by mutableStateOf<String?>(null)
    var speed by mutableStateOf<List<SpeedSample>>(emptyList())
    @Volatile var sessionStart = 0L
    @Volatile var baseRx = 0L
    @Volatile var baseTx = 0L
}
