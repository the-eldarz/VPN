package app.fastvpn

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

data class Totals(val sessions: Long, val ms: Long, val rx: Long, val tx: Long)
data class DayStat(val day: String, val ms: Long, val rx: Long, val tx: Long)

object Stats {
    private fun p(ctx: Context) = ctx.applicationContext.getSharedPreferences("stats", 0)
    private fun today() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Calendar.getInstance().time)

    fun addSession(ctx: Context, rx: Long, tx: Long, ms: Long) {
        val p = p(ctx)
        val d = today()
        p.edit()
            .putLong("n", p.getLong("n", 0) + 1)
            .putLong("ms", p.getLong("ms", 0) + ms)
            .putLong("rx", p.getLong("rx", 0) + rx)
            .putLong("tx", p.getLong("tx", 0) + tx)
            .putLong("ms_$d", p.getLong("ms_$d", 0) + ms)
            .putLong("rx_$d", p.getLong("rx_$d", 0) + rx)
            .putLong("tx_$d", p.getLong("tx_$d", 0) + tx)
            .apply()
    }

    fun totals(ctx: Context): Totals {
        val p = p(ctx)
        return Totals(p.getLong("n", 0), p.getLong("ms", 0), p.getLong("rx", 0), p.getLong("tx", 0))
    }

    fun days(ctx: Context, n: Int): List<DayStat> {
        val p = p(ctx)
        val cal = Calendar.getInstance()
        val out = ArrayList<DayStat>()
        repeat(n) {
            val d = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
            out.add(DayStat(d, p.getLong("ms_$d", 0), p.getLong("rx_$d", 0), p.getLong("tx_$d", 0)))
            cal.add(Calendar.DAY_OF_YEAR, -1)
        }
        return out
    }

    fun reset(ctx: Context) { p(ctx).edit().clear().apply() }
}

fun fmtBytes(b: Long): String {
    val v = b.coerceAtLeast(0).toDouble()
    return when {
        v >= 1e9 -> "%.2f ГБ".format(v / 1e9)
        v >= 1e6 -> "%.1f МБ".format(v / 1e6)
        v >= 1e3 -> "%.0f КБ".format(v / 1e3)
        else -> "${b.coerceAtLeast(0)} Б"
    }
}

fun fmtTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%02d:%02d".format(m, sec)
}
