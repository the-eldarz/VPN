package app.fastvpn

import android.app.Application
import android.content.Context
import java.nio.ByteBuffer
import java.util.Locale

class FastApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Geo.init(this)
    }
}

/** Страна сервера: по флагу в названии, иначе по IP через встроенную базу (assets/geo4.bin). */
object Geo {
    @Volatile private var data: ByteBuffer? = null
    @Volatile private var n = 0
    private val v4 = Regex("^(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})$")

    fun init(ctx: Context) {
        if (data != null) return
        try {
            val bytes = ctx.applicationContext.assets.open("geo4.bin").use { it.readBytes() }
            data = ByteBuffer.wrap(bytes)
            n = bytes.size / 10
        } catch (e: Exception) {
            data = ByteBuffer.allocate(0)
            n = 0
        }
    }

    private fun lookup(ip: Long): String? {
        val b = data ?: return null
        var lo = 0
        var hi = n - 1
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            val off = mid * 10
            val s = b.getInt(off).toLong() and 0xFFFFFFFFL
            val e = b.getInt(off + 4).toLong() and 0xFFFFFFFFL
            if (ip < s) hi = mid - 1
            else if (ip > e) lo = mid + 1
            else return String(charArrayOf(b.get(off + 8).toInt().toChar(), b.get(off + 9).toInt().toChar()))
        }
        return null
    }

    private fun isRegional(cp: Int) = cp in 0x1F1E6..0x1F1FF

    /** Код страны из флага-эмодзи в названии (🇷🇺 -> RU). */
    fun flagFromName(name: String): String? {
        var i = 0
        while (i < name.length) {
            val cp = name.codePointAt(i)
            i += Character.charCount(cp)
            if (isRegional(cp) && i < name.length) {
                val cp2 = name.codePointAt(i)
                if (isRegional(cp2)) {
                    return "" + ('A' + (cp - 0x1F1E6)) + ('A' + (cp2 - 0x1F1E6))
                }
            }
        }
        return null
    }

    fun stripFlags(name: String): String {
        val sb = StringBuilder()
        var i = 0
        while (i < name.length) {
            val cp = name.codePointAt(i)
            i += Character.charCount(cp)
            if (!isRegional(cp)) sb.appendCodePoint(cp)
        }
        return sb.toString().trim()
    }

    fun country(name: String, host: String): String? {
        flagFromName(name)?.let { return it }
        val m = v4.matchEntire(host) ?: return null
        val p = m.groupValues.drop(1).map { it.toInt() }
        if (p.any { it > 255 }) return null
        val ip = (p[0].toLong() shl 24) or (p[1].toLong() shl 16) or (p[2].toLong() shl 8) or p[3].toLong()
        return lookup(ip)
    }

    fun flag(cc: String?): String {
        if (cc == null || cc.length != 2) return "🌐"
        val a = cc[0].uppercaseChar()
        val b = cc[1].uppercaseChar()
        if (a !in 'A'..'Z' || b !in 'A'..'Z') return "🌐"
        return String(Character.toChars(0x1F1E6 + (a - 'A'))) + String(Character.toChars(0x1F1E6 + (b - 'A')))
    }

    fun countryName(cc: String?): String {
        if (cc == null) return "Страна неизвестна"
        val n = Locale("", cc).getDisplayCountry(Locale("ru"))
        return if (n.isBlank()) cc else n
    }

    /** Название сервера без флага и без повтора страны (то, что идёт «мелким шрифтом»). */
    fun remark(s: Server): String {
        val n = stripFlags(s.name)
        return if (n.equals(countryName(s.cc), ignoreCase = true)) "" else n
    }
}
