package app.fastvpn

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLDecoder

/** Превращает ссылку (vless/vmess/trojan/ss) в JSON-конфиг Xray с локальным SOCKS на 127.0.0.1. */
object XrayConfig {
    const val SOCKS_PORT = 10808

    fun build(link: String, test: Boolean = false, port: Int = SOCKS_PORT, user: String? = null, pass: String? = null): String {
        val scheme = link.substringBefore("://").lowercase()
        val outbound = when (scheme) {
            "vless" -> vless(link)
            "vmess" -> vmess(link)
            "trojan" -> trojan(link)
            "ss" -> shadowsocks(link)
            "hysteria2", "hy2" -> hysteria2(link)
            "tuic" -> throw IllegalArgumentException("TUIC не поддерживается ядром Xray")
            else -> throw IllegalArgumentException("Протокол $scheme пока не поддерживается")
        }
        outbound.put("tag", "proxy")
        val socks = JSONObject().put("udp", true)
        if (user != null && pass != null) {
            socks.put("auth", "password")
                .put("accounts", JSONArray().put(JSONObject().put("user", user).put("pass", pass)))
        } else socks.put("auth", "noauth")
        val inbound = JSONObject()
            .put("tag", "socks").put("listen", "127.0.0.1").put("port", port).put("protocol", "socks")
            .put("settings", socks)
        return JSONObject()
            .put("log", JSONObject().put("loglevel", "warning"))
            .put("dns", JSONObject().put("servers", JSONArray().put("1.1.1.1").put("8.8.8.8")))
            .put("inbounds", if (test) JSONArray() else JSONArray().put(inbound))
            .put("outbounds", JSONArray().put(outbound).put(JSONObject().put("protocol", "freedom").put("tag", "direct")))
            .toString()
    }

    private class U(val user: String, val host: String, val port: Int, val q: Map<String, String>)

    private fun dec(s: String) = URLDecoder.decode(s, "UTF-8")
    private fun Map<String, String>.g(k: String): String? = this[k]?.takeIf { it.isNotBlank() }

    private fun hostPort(auth: String): Pair<String, Int> =
        if (auth.startsWith("[")) auth.substringBefore(']').drop(1) to auth.substringAfter("]:").toInt()
        else auth.substringBeforeLast(':') to auth.substringAfterLast(':').toInt()

    private fun url(l: String): U {
        val rest = l.substringAfter("://").substringBefore('#')
        val main = rest.substringBefore('?').substringBefore('/')
        val query = rest.substringAfter('?', "")
        val (h, p) = hostPort(main.substringAfterLast('@'))
        val q = query.split('&').filter { it.contains('=') }
            .associate { it.substringBefore('=') to dec(it.substringAfter('=')) }
        return U(dec(main.substringBeforeLast('@', "")), h, p, q)
    }

    private fun b64(s: String): String =
        String(Base64.decode(s.replace('-', '+').replace('_', '/'), Base64.DEFAULT))

    private fun stream(q: Map<String, String>, host: String, defSec: String = "none"): JSONObject {
        val s = JSONObject()
        val net = when (val t = q.g("type") ?: "tcp") { "splithttp" -> "xhttp"; "raw" -> "tcp"; else -> t }
        s.put("network", net)
        val rawSec = q.g("security")
        val sec = if (rawSec == null) defSec else if (rawSec == "tls" || rawSec == "reality") rawSec else "none"
        s.put("security", sec)
        when (sec) {
            "tls" -> {
                val t = JSONObject().put("serverName", q.g("sni") ?: q.g("host") ?: host)
                    .put("fingerprint", q.g("fp") ?: "chrome")
                q.g("alpn")?.let { t.put("alpn", JSONArray(it.split(','))) }
                if (q["allowInsecure"] == "1" || q["insecure"] == "1") t.put("allowInsecure", true)
                s.put("tlsSettings", t)
            }
            "reality" -> s.put("realitySettings", JSONObject()
                .put("serverName", q.g("sni") ?: host)
                .put("fingerprint", q.g("fp") ?: "chrome")
                .put("publicKey", q.g("pbk") ?: "")
                .put("shortId", q.g("sid") ?: "")
                .put("spiderX", q.g("spx") ?: "")
                .also { r -> q.g("pqv")?.let { r.put("mldsa65Verify", it) } })
        }
        val path = q.g("path") ?: "/"
        val hostHdr = q.g("host") ?: q.g("sni") ?: host
        when (net) {
            "ws" -> s.put("wsSettings", JSONObject().put("path", path)
                .put("headers", JSONObject().put("Host", hostHdr)))
            "grpc" -> {
                val g = JSONObject().put("serviceName", q.g("serviceName") ?: "").put("multiMode", q["mode"] == "multi")
                q.g("authority")?.let { g.put("authority", it) }
                s.put("grpcSettings", g)
            }
            "httpupgrade" -> s.put("httpupgradeSettings", JSONObject().put("path", path).put("host", hostHdr))
            "xhttp" -> {
                val w = JSONObject().put("path", path).put("mode", q.g("mode") ?: "auto").put("host", hostHdr)
                q.g("extra")?.let { e -> runCatching { w.put("extra", JSONObject(e)) } }
                s.put("xhttpSettings", w)
            }
            "tcp" -> if (q["headerType"] == "http") {
                val req = JSONObject().put("path", JSONArray().put(path))
                q.g("host")?.let { req.put("headers", JSONObject().put("Host", JSONArray(it.split(',')))) }
                s.put("tcpSettings", JSONObject().put("header", JSONObject().put("type", "http").put("request", req)))
            }
        }
        return s
    }

    private val dnsCache = java.util.concurrent.ConcurrentHashMap<String, Pair<String, Long>>()
    private val ipRe = Regex("^[0-9.]+$|.*:.*")

    /** Домен сервера -> IP средствами системы (приложение исключено из VPN, DNS работает напрямую). */
    private fun resolve(host: String): String {
        if (ipRe.matches(host)) return host
        val now = System.currentTimeMillis()
        dnsCache[host]?.let { if (now - it.second < 300_000) return it.first }
        return try {
            val all = java.net.InetAddress.getAllByName(host)
            val ip = (all.firstOrNull { it is java.net.Inet4Address } ?: all.first()).hostAddress ?: host
            dnsCache[host] = ip to now
            ip
        } catch (e: Exception) { host }
    }

    private fun server(host: String, port: Int) = JSONObject().put("address", resolve(host)).put("port", port)

    private fun vless(l: String): JSONObject {
        val u = url(l)
        val user = JSONObject().put("id", u.user).put("encryption", u.q.g("encryption") ?: "none")
        u.q.g("flow")?.let { user.put("flow", it) }
        return JSONObject().put("protocol", "vless")
            .put("settings", JSONObject().put("vnext", JSONArray().put(server(u.host, u.port).put("users", JSONArray().put(user)))))
            .put("streamSettings", stream(u.q, u.host))
    }

    private fun vmess(l: String): JSONObject {
        val o = JSONObject(b64(l.substringAfter("://").substringBefore('#')))
        val host = o.getString("add")
        val port = o.get("port").toString().toInt()
        val q = mapOf(
            "type" to o.optString("net", "tcp"),
            "security" to if (o.optString("tls") == "tls") "tls" else "none",
            "sni" to o.optString("sni"), "host" to o.optString("host"), "path" to o.optString("path"),
            "serviceName" to o.optString("path"), "alpn" to o.optString("alpn"), "fp" to o.optString("fp")
        )
        val user = JSONObject().put("id", o.getString("id"))
            .put("alterId", o.opt("aid")?.toString()?.toIntOrNull() ?: 0)
            .put("security", o.optString("scy").ifBlank { "auto" })
        return JSONObject().put("protocol", "vmess")
            .put("settings", JSONObject().put("vnext", JSONArray().put(server(host, port).put("users", JSONArray().put(user)))))
            .put("streamSettings", stream(q, host))
    }

    private fun trojan(l: String): JSONObject {
        val u = url(l)
        return JSONObject().put("protocol", "trojan")
            .put("settings", JSONObject().put("servers", JSONArray().put(server(u.host, u.port).put("password", u.user))))
            .put("streamSettings", stream(u.q, u.host, "tls"))
    }

    private fun shadowsocks(link: String): JSONObject {
        val l = Parser.normalizeSs(link)
        val main = l.substringAfter("://").substringBefore('#').substringBefore('?')
        val info = main.substringBeforeLast('@')
        val cred = if (info.contains(':')) dec(info.replace("+", "%2B")) else b64(info)
        val (h, p) = hostPort(main.substringAfterLast('@'))
        return JSONObject().put("protocol", "shadowsocks")
            .put("settings", JSONObject().put("servers", JSONArray().put(
                server(h, p).put("method", cred.substringBefore(':')).put("password", cred.substringAfter(':')))))
    }

    private fun hysteria2(l: String): JSONObject {
        val u = url(l)
        if (u.q.g("obfs") != null) throw IllegalArgumentException("Hysteria2 с obfs пока не поддерживается")
        val tls = JSONObject().put("serverName", u.q.g("sni") ?: u.host).put("alpn", JSONArray().put("h3"))
        if (u.q["insecure"] == "1" || u.q["allowInsecure"] == "1") tls.put("allowInsecure", true)
        val st = JSONObject().put("network", "hysteria").put("security", "tls").put("tlsSettings", tls)
            .put("hysteriaSettings", JSONObject().put("version", 2).put("auth", u.user))
        return JSONObject().put("protocol", "hysteria")
            .put("settings", JSONObject().put("version", 2).put("address", resolve(u.host)).put("port", u.port))
            .put("streamSettings", st)
    }
}
