package app.fastvpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.TrafficStats
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.os.Process
import android.os.SystemClock
import fastcore.Fastcore
import kotlinx.coroutines.runBlocking
import java.io.File

class FastVpnService : VpnService() {
    private var pfd: ParcelFileDescriptor? = null
    private var tunStarted = false
    private var coreStarted = false
    private var sessionActive = false

    companion object {
        const val ACTION_STOP = "app.fastvpn.STOP"
        const val ACTION_START_LAST = "app.fastvpn.START_LAST"
        const val EXTRA_LINK = "link"

        private fun launch(ctx: Context, i: Intent) {
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }

        fun start(ctx: Context, link: String) =
            launch(ctx, Intent(ctx, FastVpnService::class.java).putExtra(EXTRA_LINK, link))

        /** Подключение к сохранённому серверу или к самому быстрому (если включено автоподключение). */
        fun startLast(ctx: Context) =
            launch(ctx, Intent(ctx, FastVpnService::class.java).setAction(ACTION_START_LAST))

        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, FastVpnService::class.java).setAction(ACTION_STOP))
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(1, notification())
        when (intent?.action) {
            ACTION_STOP -> Thread { stopVpn() }.start()
            ACTION_START_LAST -> Thread { startLast() }.start()
            else -> {
                val link = intent?.getStringExtra(EXTRA_LINK)
                if (link == null) Thread { stopVpn() }.start() else Thread { startVpn(link) }.start()
            }
        }
        return START_NOT_STICKY
    }

    private fun startLast() {
        VpnState.message = "Подбор сервера…"
        val t = try { runBlocking { Auto.resolveTarget(applicationContext) } } catch (e: Throwable) { null }
        if (t == null) fail("Сервер не найден — выберите его в приложении") else startVpn(t.link)
    }

    @Synchronized
    private fun fail(msg: String) {
        teardown()
        VpnState.running = false
        VpnState.message = msg
        Ui.refresh(this)
        stopForeground(true)
        stopSelf()
    }

    @Synchronized
    private fun startVpn(link: String) {
        try {
            teardown()
            val cfg = XrayConfig.build(link)
            Fastcore.start(cfg)
            coreStarted = true
            val b = Builder()
                .setSession("FastVpn")
                .setMtu(1500)
                .addAddress("198.18.0.1", 30)
                .addRoute("0.0.0.0", 0)
                .addAddress("fd00:198:18::1", 126)
                .addRoute("::", 0)
                .addDnsServer("1.1.1.1")
                .addDnsServer("8.8.8.8")
            try { b.addDisallowedApplication(packageName) } catch (_: Exception) { }
            val fd = b.establish() ?: throw IllegalStateException("Не удалось создать VPN-интерфейс")
            pfd = fd
            val yml = File(filesDir, "hev.yml")
            yml.writeText(
                "tunnel:\n  mtu: 1500\n  ipv4: 198.18.0.1\n  ipv6: 'fd00:198:18::1'\n" +
                "socks5:\n  port: ${XrayConfig.SOCKS_PORT}\n  address: 127.0.0.1\n  udp: 'udp'\n"
            )
            TunBridge.start(yml.absolutePath, fd.fd)
            tunStarted = true
            val uid = Process.myUid()
            VpnState.baseRx = TrafficStats.getUidRxBytes(uid).coerceAtLeast(0)
            VpnState.baseTx = TrafficStats.getUidTxBytes(uid).coerceAtLeast(0)
            VpnState.sessionStart = SystemClock.elapsedRealtime()
            sessionActive = true
            VpnState.message = null
            VpnState.running = true
            Ui.refresh(this)
        } catch (e: Throwable) {
            fail("Ошибка: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    @Synchronized
    private fun stopVpn() {
        teardown()
        VpnState.running = false
        VpnState.message = null
        Ui.refresh(this)
        stopForeground(true)
        stopSelf()
    }

    private fun teardown() {
        if (sessionActive) {
            sessionActive = false
            val uid = Process.myUid()
            val rx = (TrafficStats.getUidRxBytes(uid) - VpnState.baseRx).coerceAtLeast(0)
            val tx = (TrafficStats.getUidTxBytes(uid) - VpnState.baseTx).coerceAtLeast(0)
            Stats.addSession(this, rx, tx, SystemClock.elapsedRealtime() - VpnState.sessionStart)
        }
        if (tunStarted) { runCatching { TunBridge.stop() }; tunStarted = false }
        if (coreStarted) { runCatching { Fastcore.stop() }; coreStarted = false }
        runCatching { pfd?.close() }
        pfd = null
    }

    override fun onRevoke() { stopVpn() }

    override fun onDestroy() {
        teardown()
        VpnState.running = false
        Ui.refresh(this)
        super.onDestroy()
    }

    private fun notification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("vpn", "VPN", NotificationManager.IMPORTANCE_LOW))
        }
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "vpn") else Notification.Builder(this)
        return b.setContentTitle("FastVpn").setContentText("VPN активен")
            .setSmallIcon(android.R.drawable.ic_lock_lock).setContentIntent(pi).build()
    }
}
