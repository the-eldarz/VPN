package app.fastvpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.TrafficStats
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.os.Process
import android.os.SystemClock
import fastcore.Fastcore
import kotlinx.coroutines.runBlocking
import java.io.File
import java.security.SecureRandom
import java.util.concurrent.atomic.AtomicBoolean

class FastVpnService : VpnService() {
    private var pfd: ParcelFileDescriptor? = null
    private var tunStarted = false
    private var coreStarted = false
    private var sessionActive = false
    @Volatile private var epoch = 0
    @Volatile private var reconnecting = false
    private var currentLink: String? = null
    private var port = XrayConfig.SOCKS_PORT
    private var user: String? = null
    private var pass: String? = null

    private val netChanged = AtomicBoolean(false)
    @Volatile private var netArmedAt = 0L
    private var cm: ConnectivityManager? = null
    private var netCb: ConnectivityManager.NetworkCallback? = null

    private val prefs by lazy { getSharedPreferences("s", 0) }

    companion object {
        const val ACTION_STOP = "app.fastvpn.STOP"
        const val ACTION_START_LAST = "app.fastvpn.START_LAST"
        const val EXTRA_LINK = "link"
        private const val HEALTH_URL = "https://www.gstatic.com/generate_204"

        private fun launch(ctx: Context, i: Intent) {
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }

        fun start(ctx: Context, link: String) =
            launch(ctx, Intent(ctx, FastVpnService::class.java).putExtra(EXTRA_LINK, link))

        /** Подключение к сохранённому серверу или к самому быстрому (если включено автоподключение). */
        fun startLast(ctx: Context) =
            launch(ctx, Intent(ctx, FastVpnService::class.java).setAction(ACTION_START_LAST))

        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, FastVpnService::class.java).setAction(ACTION_STOP))
        }
    }

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(NotificationChannel("vpn", "VPN", NotificationManager.IMPORTANCE_LOW))
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(1, notification("VPN запускается…"))
        when (intent?.action) {
            ACTION_STOP -> Thread { stopVpn() }.start()
            ACTION_START_LAST -> Thread { startLast() }.start()
            else -> {
                val link = intent?.getStringExtra(EXTRA_LINK)
                if (link == null) Thread { stopVpn() }.start() else Thread { startVpn(link) }.start()
            }
        }
        return START_NOT_STICKY
    }

    private fun startLast() {
        VpnState.message = "Подбор сервера…"
        val t = try { runBlocking { Auto.resolveTarget(applicationContext) } } catch (e: Throwable) { null }
        if (t == null) fail("Сервер не найден — выберите его в приложении") else startVpn(t.link)
    }

    // ------------------------------------------------------------------ запуск / остановка

    @Synchronized
    private fun startVpn(link: String) {
        try {
            teardown()
            launchCore(link)
            val b = Builder()
                .setSession("FastVpn")
                .setMtu(1500)
                .addAddress("198.18.0.1", 30)
                .addRoute("0.0.0.0", 0)
                .addAddress("fd00:198:18::1", 126)
                .addRoute("::", 0)
                .addDnsServer("1.1.1.1")
                .addDnsServer("8.8.8.8")
            applySplit(b)
            pfd = b.establish() ?: throw IllegalStateException("Не удалось создать VPN-интерфейс")
            startHev()
            currentLink = link
            VpnState.serverName = Parser.parseOne(link)?.name
            VpnState.message = null
            VpnState.notice = null
            beginSession()
            VpnState.running = true
            Ui.refresh(this)
        } catch (e: Throwable) {
            fail("Ошибка: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    /** Смена сервера без разрыва туннеля: интерфейс остаётся, трафик на время смены блокируется, а не уходит мимо. */
    @Synchronized
    private fun switchServer(link: String) {
        if (tunStarted) { runCatching { TunBridge.stop() }; tunStarted = false }
        if (coreStarted) { runCatching { Fastcore.stop() }; coreStarted = false }
        launchCore(link)
        startHev()
        currentLink = link
        VpnState.serverName = Parser.parseOne(link)?.name
    }

    private fun applySplit(b: Builder) {
        val mode = prefs.getString("splitMode", "all") ?: "all"
        val apps = prefs.getStringSet("splitApps", emptySet()) ?: emptySet()
        var allowed = 0
        if (mode == "only" && apps.isNotEmpty()) {
            for (a in apps) try { b.addAllowedApplication(a); allowed++ } catch (_: Exception) { }
        }
        if (allowed == 0) {
            if (mode == "except") for (a in apps) try { b.addDisallowedApplication(a) } catch (_: Exception) { }
            // само приложение никогда не должно идти через свой же туннель
            try { b.addDisallowedApplication(packageName) } catch (_: Exception) { }
        }
    }

    private fun rand(n: Int): String {
        val chars = "abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val r = SecureRandom()
        return String(CharArray(n) { chars[r.nextInt(chars.length)] })
    }

    private fun freePort(): Int = try {
        java.net.ServerSocket(0).use { it.localPort }
    } catch (e: Exception) { 20000 + SecureRandom().nextInt(30000) }

    /** Запускает Xray на случайном порту, а при поддержке tun2socks — ещё и с паролем. */
    private fun launchCore(link: String) {
        port = freePort()
        user = rand(12)
        pass = rand(20)
        val cfg = XrayConfig.build(
            link, false, port,
            if (HevCaps.AUTH) user else null, if (HevCaps.AUTH) pass else null
        )
        Fastcore.start(cfg)
        coreStarted = true
    }

    private fun startHev() {
        val fd = pfd ?: throw IllegalStateException("Нет VPN-интерфейса")
        val yml = File(filesDir, "hev.yml")
        val auth = if (HevCaps.AUTH) "  username: '$user'\n  password: '$pass'\n" else ""
        yml.writeText(
            "tunnel:\n  mtu: 1500\n  ipv4: 198.18.0.1\n  ipv6: 'fd00:198:18::1'\n" +
            "socks5:\n  port: $port\n  address: 127.0.0.1\n  udp: 'udp'\n" + auth
        )
        TunBridge.start(yml.absolutePath, fd.fd)
        tunStarted = true
        yml.delete()
    }

    @Synchronized
    private fun fail(msg: String) {
        teardown()
        VpnState.running = false
        VpnState.message = msg
        VpnState.notice = null
        VpnState.serverName = null
        Ui.refresh(this)
        stopForeground(true)
        stopSelf()
    }

    @Synchronized
    private fun stopVpn(msg: String? = null) {
        teardown()
        VpnState.running = false
        VpnState.message = msg
        VpnState.notice = null
        VpnState.serverName = null
        Ui.refresh(this)
        stopForeground(true)
        stopSelf()
    }

    private fun teardown() {
        epoch++   // останавливает фоновые потоки сессии
        runCatching { netCb?.let { cm?.unregisterNetworkCallback(it) } }
        netCb = null
        if (sessionActive) {
            sessionActive = false
            val uid = Process.myUid()
            val rx = (TrafficStats.getUidRxBytes(uid) - VpnState.baseRx).coerceAtLeast(0)
            val tx = (TrafficStats.getUidTxBytes(uid) - VpnState.baseTx).coerceAtLeast(0)
            Stats.addSession(this, rx, tx, SystemClock.elapsedRealtime() - VpnState.sessionStart)
        }
        if (tunStarted) { runCatching { TunBridge.stop() }; tunStarted = false }
        if (coreStarted) { runCatching { Fastcore.stop() }; coreStarted = false }
        runCatching { pfd?.close() }
        pfd = null
    }

    override fun onRevoke() { stopVpn() }

    override fun onDestroy() {
        teardown()
        VpnState.running = false
        Ui.refresh(this)
        super.onDestroy()
    }

    // ------------------------------------------------------------------ сессия: скорость, здоровье, сеть

    private fun beginSession() {
        val uid = Process.myUid()
        VpnState.baseRx = TrafficStats.getUidRxBytes(uid).coerceAtLeast(0)
        VpnState.baseTx = TrafficStats.getUidTxBytes(uid).coerceAtLeast(0)
        VpnState.sessionStart = SystemClock.elapsedRealtime()
        VpnState.speed = emptyList()
        sessionActive = true
        epoch++
        val my = epoch
        registerNet()
        startMonitor(my)
        startHealth(my)
    }

    private fun registerNet() {
        try {
            val m = getSystemService(ConnectivityManager::class.java)
            val cb = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    if (System.currentTimeMillis() > netArmedAt) netChanged.set(true)
                }
                override fun onLost(network: Network) {
                    if (System.currentTimeMillis() > netArmedAt) netChanged.set(true)
                }
            }
            netArmedAt = System.currentTimeMillis() + 3000
            m.registerNetworkCallback(
                NetworkRequest.Builder()
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
                    .build(),
                cb
            )
            cm = m
            netCb = cb
        } catch (_: Exception) { }
    }

    /** Раз в секунду: скорость для графика и уведомления. */
    private fun startMonitor(my: Int) {
        Thread {
            try {
                val uid = Process.myUid()
                var lastRx = TrafficStats.getUidRxBytes(uid)
                var lastTx = TrafficStats.getUidTxBytes(uid)
                val hist = ArrayList<SpeedSample>()
                while (epoch == my) {
                    Thread.sleep(1000)
                    if (epoch != my) break
                    val rx = TrafficStats.getUidRxBytes(uid)
                    val tx = TrafficStats.getUidTxBytes(uid)
                    val dr = (rx - lastRx).coerceAtLeast(0).toFloat()
                    val dt = (tx - lastTx).coerceAtLeast(0).toFloat()
                    lastRx = rx; lastTx = tx
                    hist.add(SpeedSample(dr, dt))
                    if (hist.size > 60) hist.removeAt(0)
                    VpnState.speed = hist.toList()
                    val text = "↓ ${fmtBytes(dr.toLong())}/с  ↑ ${fmtBytes(dt.toLong())}/с  ·  " +
                        fmtTime(SystemClock.elapsedRealtime() - VpnState.sessionStart)
                    getSystemService(NotificationManager::class.java).notify(1, notification(text))
                }
            } catch (_: Throwable) { }
        }.also { it.isDaemon = true; it.start() }
    }

    private fun healthy(): Boolean = try { Fastcore.health(HEALTH_URL, 6L); true } catch (e: Throwable) { false }

    /** Проверка живости сервера и реакция на смену сети. */
    private fun startHealth(my: Int) {
        Thread {
            try {
                var fails = 0
                var since = 0
                while (epoch == my) {
                    Thread.sleep(1000)
                    if (epoch != my) break
                    since++
                    val netEvent = netChanged.getAndSet(false)
                    if (netEvent) { Thread.sleep(2500); since = 25 }
                    if (reconnecting || !prefs.getBoolean("autoReconnect", true)) { if (since > 25) since = 0; continue }
                    if (since < 25) continue
                    since = 0
                    var ok = healthy()
                    if (!ok && netEvent) { Thread.sleep(3000); ok = healthy() }
                    if (ok) {
                        fails = 0
                    } else {
                        fails++
                        if (fails >= 2 || netEvent) {
                            fails = 0
                            reconnect(if (netEvent) "Сеть сменилась" else "Сервер не отвечает", my)
                        } else since = 15   // повторная проверка через 10 секунд
                    }
                }
            } catch (_: Throwable) { }
        }.also { it.isDaemon = true; it.start() }
    }

    private fun sleepSec(n: Int, my: Int) {
        var i = 0
        while (i < n && epoch == my) { Thread.sleep(1000); i++ }
    }

    /** Подбирает новый быстрый сервер и переключается на него, не закрывая туннель. */
    private fun reconnect(reason: String, my: Int) {
        if (reconnecting) return
        reconnecting = true
        try {
            var attempts = 0
            while (epoch == my) {
                VpnState.notice = "$reason — подбираем новый сервер…"
                val group = prefs.getString("autoGroup", "all") ?: "all"
                val t = try {
                    runBlocking { Auto.fastest(applicationContext, group, currentLink) }
                } catch (e: Throwable) { null }
                if (epoch != my) return
                if (t != null) {
                    val switched = try { switchServer(t.link); true } catch (e: Throwable) { false }
                    if (epoch != my) return
                    if (switched && healthy()) {
                        prefs.edit().putString("sel", t.link).apply()
                        VpnState.notice = null
                        return
                    }
                }
                attempts++
                val kill = prefs.getBoolean("killSwitch", false)
                if (attempts >= 3 && !kill) {
                    Thread { stopVpn("Сервер недоступен — VPN отключён") }.start()
                    return
                }
                VpnState.notice = if (kill) "Нет рабочих серверов, интернет заблокирован. Повторяем…"
                else "Нет рабочих серверов. Повторяем…"
                sleepSec(15, my)
            }
        } finally {
            reconnecting = false
        }
    }

    // ------------------------------------------------------------------ уведомление

    private fun notification(text: String): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stopPi = PendingIntent.getService(
            this, 1, Intent(this, FastVpnService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "vpn") else Notification.Builder(this)
        val title = "FastVpn" + (VpnState.serverName?.let { " · $it" } ?: "")
        return b.setContentTitle(title).setContentText(text)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Стоп", stopPi
                ).build()
            )
            .build()
    }
}
