package app.fastvpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import fastcore.Fastcore
import java.io.File

class FastVpnService : VpnService() {
    private var pfd: ParcelFileDescriptor? = null
    private var tunStarted = false
    private var coreStarted = false

    companion object {
        const val ACTION_STOP = "app.fastvpn.STOP"
        const val EXTRA_LINK = "link"

        fun start(ctx: Context, link: String) {
            val i = Intent(ctx, FastVpnService::class.java).putExtra(EXTRA_LINK, link)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }

        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, FastVpnService::class.java).setAction(ACTION_STOP))
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(1, notification())
        if (intent?.action == ACTION_STOP) {
            Thread { stopVpn() }.start()
            return START_NOT_STICKY
        }
        val link = intent?.getStringExtra(EXTRA_LINK)
        if (link == null) { stopVpn(); return START_NOT_STICKY }
        Thread { startVpn(link) }.start()
        return START_NOT_STICKY
    }

    @Synchronized
    private fun startVpn(link: String) {
        try {
            teardown()
            val cfg = XrayConfig.build(link)
            Fastcore.start(cfg)
            coreStarted = true
            val b = Builder()
                .setSession("FastVpn")
                .setMtu(1500)
                .addAddress("198.18.0.1", 30)
                .addRoute("0.0.0.0", 0)
                .addDnsServer("1.1.1.1")
                .addDnsServer("8.8.8.8")
            try { b.addDisallowedApplication(packageName) } catch (_: Exception) { }
            val fd = b.establish() ?: throw IllegalStateException("Не удалось создать VPN-интерфейс")
            pfd = fd
            val yml = File(filesDir, "hev.yml")
            yml.writeText(
                "tunnel:\n  mtu: 1500\n  ipv4: 198.18.0.1\n" +
                "socks5:\n  port: ${XrayConfig.SOCKS_PORT}\n  address: 127.0.0.1\n  udp: 'udp'\n"
            )
            TunBridge.start(yml.absolutePath, fd.fd)
            tunStarted = true
            VpnState.message = null
            VpnState.running = true
        } catch (e: Throwable) {
            teardown()
            VpnState.running = false
            VpnState.message = "Ошибка: ${e.message ?: e.javaClass.simpleName}"
            stopForeground(true)
            stopSelf()
        }
    }

    @Synchronized
    private fun stopVpn() {
        teardown()
        VpnState.running = false
        VpnState.message = null
        stopForeground(true)
        stopSelf()
    }

    private fun teardown() {
        if (tunStarted) { runCatching { TunBridge.stop() }; tunStarted = false }
        if (coreStarted) { runCatching { Fastcore.stop() }; coreStarted = false }
        runCatching { pfd?.close() }
        pfd = null
    }

    override fun onRevoke() { stopVpn() }

    override fun onDestroy() {
        teardown()
        VpnState.running = false
        super.onDestroy()
    }

    private fun notification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("vpn", "VPN", NotificationManager.IMPORTANCE_LOW))
        }
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "vpn") else Notification.Builder(this)
        return b.setContentTitle("FastVpn").setContentText("VPN активен")
            .setSmallIcon(android.R.drawable.ic_lock_lock).setContentIntent(pi).build()
    }
}
