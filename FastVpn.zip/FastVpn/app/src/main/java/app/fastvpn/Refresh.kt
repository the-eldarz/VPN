package app.fastvpn

import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.ComponentName
import android.content.Context

/** Фоновое обновление списков серверов. */
object Refresh {
    private const val JOB_ID = 4242

    fun schedule(ctx: Context) {
        val c = ctx.applicationContext
        val js = c.getSystemService(JobScheduler::class.java) ?: return
        val p = c.getSharedPreferences("s", 0)
        val hours = p.getInt("refreshHours", 6)
        if (hours <= 0) { js.cancel(JOB_ID); return }
        val interval = hours * 3_600_000L
        val net = if (p.getBoolean("refreshWifiOnly", true)) JobInfo.NETWORK_TYPE_UNMETERED else JobInfo.NETWORK_TYPE_ANY
        val cur = js.getPendingJob(JOB_ID)
        if (cur != null && cur.intervalMillis == interval && cur.networkType == net) return
        try {
            js.schedule(
                JobInfo.Builder(JOB_ID, ComponentName(c, RefreshJobService::class.java))
                    .setPeriodic(interval)
                    .setRequiredNetworkType(net)
                    .setPersisted(true)
                    .build()
            )
        } catch (_: Exception) { }
    }

    /** Заново скачивает списки: по 8 подгрупп каждой группы (статические первыми). */
    suspend fun run(ctx: Context, cancelled: () -> Boolean) {
        val repo = Repo(ctx.applicationContext)
        for (g in Catalog.groups) {
            if (cancelled()) return
            val subs = ArrayList<Subgroup>(g.subgroups)
            if (g.repo != null) { try { subs.addAll(repo.discover(g, true)) } catch (_: Exception) { } }
            for (sg in subs.distinctBy { it.url }.take(8)) {
                if (cancelled()) return
                try { repo.load(sg, true) } catch (_: Exception) { }
            }
        }
        ctx.applicationContext.getSharedPreferences("s", 0)
            .edit().putLong("lastRefresh", System.currentTimeMillis()).apply()
    }
}

class RefreshJobService : JobService() {
    @Volatile private var cancelled = false

    override fun onStartJob(params: JobParameters): Boolean {
        cancelled = false
        Thread {
            try { kotlinx.coroutines.runBlocking { Refresh.run(applicationContext) { cancelled } } } catch (_: Throwable) { }
            jobFinished(params, false)
        }.start()
        return true
    }

    override fun onStopJob(params: JobParameters): Boolean {
        cancelled = true
        return true
    }
}
