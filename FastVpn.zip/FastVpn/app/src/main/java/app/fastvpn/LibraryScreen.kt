package app.fastvpn

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

/** Страница 0 — «Избранное», дальше по одной странице на каждую группу. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Library(vm: MainViewModel, pager: PagerState, onOpen: (Subgroup) -> Unit) {
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize()) {
        ScrollableTabRow(selectedTabIndex = pager.currentPage, edgePadding = 8.dp) {
            Tab(
                selected = pager.currentPage == 0,
                onClick = { scope.launch { pager.animateScrollToPage(0) } },
                text = { Text("★ Избранное", maxLines = 1) }
            )
            Catalog.groups.forEachIndexed { i, g ->
                Tab(
                    selected = pager.currentPage == i + 1,
                    onClick = { scope.launch { pager.animateScrollToPage(i + 1) } },
                    text = { Text(g.title, maxLines = 1) }
                )
            }
        }
        HorizontalPager(state = pager, modifier = Modifier.fillMaxSize()) { page ->
            if (page == 0) FavoritesPage(vm) else GroupPage(vm, Catalog.groups[page - 1], onOpen)
        }
    }
}

@Composable
fun FavoritesPage(vm: MainViewModel) {
    val st = vm.subStats["favorites"]
    val testing = "favorites" in vm.testing
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(vertical = 8.dp)) {
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    when {
                        vm.favorites.isEmpty() -> "Нажмите на звёздочку у сервера, и он появится здесь"
                        st == null -> "Серверов: ${vm.favorites.size}"
                        !st.done -> "Проверка… ${st.tested}/${st.total} · работает ${st.ok}"
                        else -> "Работает ${st.ok} из ${st.total}" + (st.best?.let { " · лучший $it мс" } ?: "")
                    },
                    Modifier.weight(1f), style = MaterialTheme.typography.bodySmall
                )
                TextButton(onClick = { vm.testFavorites() }, enabled = !testing && vm.favorites.isNotEmpty()) {
                    Text("Проверить")
                }
            }
        }
        items(vm.favorites, key = { it.link }) { s -> ServerRow(vm, s) }
    }
}

@Composable
fun GroupPage(vm: MainViewModel, g: Group, onOpen: (Subgroup) -> Unit) {
    LaunchedEffect(g.id) { vm.loadGroup(g) }
    val subs = (g.subgroups + vm.groupSubs[g.id].orEmpty()).distinctBy { it.url }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item { Text(g.author, style = MaterialTheme.typography.bodySmall) }
        items(subs, key = { it.id }) { sg -> SubRow(vm, sg, onOpen) }
        item {
            if (("g:" + g.id) in vm.loading) LinearProgressIndicator(Modifier.fillMaxWidth())
            vm.groupError[g.id]?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            if (g.repo != null && vm.groupSubs.containsKey(g.id) && subs.isEmpty()) {
                Text("В репозитории нет подходящих .txt-файлов с подписками")
            }
        }
        if (g.repo != null) {
            item { TextButton(onClick = { vm.loadGroup(g, true) }) { Text("Обновить список файлов") } }
        }
    }
}

@Composable
fun SubRow(vm: MainViewModel, sg: Subgroup, onOpen: (Subgroup) -> Unit) {
    val st = vm.subStats[sg.id]
    val busy = sg.id in vm.testing
    Card(Modifier.fillMaxWidth().clickable { onOpen(sg) }) {
        ListItem(
            headlineContent = { Text(sg.title, maxLines = 2, overflow = TextOverflow.Ellipsis) },
            supportingContent = {
                Text(
                    when {
                        st == null -> sg.desc
                        !st.done -> "Проверка… ${st.tested}/${st.total} · работает ${st.ok}"
                        else -> "Работает ${st.ok} из ${st.total}" + (st.best?.let { " · лучший $it мс" } ?: "")
                    }
                )
            },
            trailingContent = {
                IconButton(onClick = { vm.testSubgroup(sg, true) }, enabled = !busy) {
                    if (busy) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                    else Icon(Icons.Default.Refresh, "Проверить пинг")
                }
            },
            colors = ListItemDefaults.colors(containerColor = Color.Transparent)
        )
    }
}

@Composable
fun ServerRow(vm: MainViewModel, s: Server) {
    val p = vm.pings[s.link]
    val err = if (p != null && p < 0) Diag.errors[s.link] else null
    val fav = vm.isFavorite(s)
    ListItem(
        headlineContent = { Text(s.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        supportingContent = { Text("${s.host}:${s.port}" + (err?.let { " · $it" } ?: ""), maxLines = 2) },
        trailingContent = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (p != null) Text(if (p < 0) "—" else "$p мс")
                if (vm.selected?.link == s.link) Icon(Icons.Default.Check, null)
                IconButton(onClick = { vm.toggleFavorite(s) }) {
                    Icon(
                        Icons.Default.Star, "Избранное",
                        tint = if (fav) Color(0xFFFFC107) else LocalContentColor.current.copy(alpha = 0.35f)
                    )
                }
            }
        },
        modifier = Modifier.clickable { vm.select(s) }
    )
}

@Composable
fun SubgroupScreen(vm: MainViewModel, sg: Subgroup, onBack: () -> Unit) {
    LaunchedEffect(sg.id) { vm.load(sg) }
    val raw = vm.servers[sg.id].orEmpty()
    val done = vm.subStats[sg.id]?.done == true
    val list = remember(raw, done) {
        if (!done) raw
        else raw.sortedWith(
            compareBy<Server> { val p = vm.pings[it.link]; if (p == null) 1 else if (p < 0) 2 else 0 }
                .thenBy { vm.pings[it.link] ?: 0 }
        )
    }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) }
            Text(sg.title, Modifier.weight(1f), style = MaterialTheme.typography.titleLarge)
            TextButton(onClick = { vm.load(sg, true) }) { Text("Обновить") }
            TextButton(onClick = { vm.testSubgroup(sg, false) }, enabled = sg.id !in vm.testing) { Text("Пинг") }
        }
        if (sg.id in vm.loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        vm.error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(16.dp)) }
        Text("Серверов: ${list.size}", Modifier.padding(horizontal = 16.dp))
        LazyColumn {
            items(list, key = { it.link }) { s -> ServerRow(vm, s) }
        }
    }
}
