package app.fastvpn

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = Repo(app)
    private val prefs = app.getSharedPreferences("s", 0)

    var auto by mutableStateOf(prefs.getBoolean("auto", false)); private set
    var theme by mutableStateOf(prefs.getString("theme", "system") ?: "system"); private set
    var autoGroup by mutableStateOf(prefs.getString("autoGroup", "all") ?: "all"); private set
    var selected by mutableStateOf(prefs.getString("sel", null)?.let { Parser.parseOne(it) }); private set
    var busy by mutableStateOf(false); private set
    var searching by mutableStateOf(false); private set
    var error by mutableStateOf<String?>(null); private set

    val connected: Boolean get() = VpnState.running
    val status: String
        get() = when {
            VpnState.running -> "Подключено"
            searching -> "Ищем самый быстрый сервер…"
            else -> VpnState.message ?: "Не подключено"
        }

    val servers = mutableStateMapOf<String, List<Server>>()
    val loading = mutableStateListOf<String>()
    val pings = mutableStateMapOf<String, Int>()
    val groupSubs = mutableStateMapOf<String, List<Subgroup>>()
    val groupError = mutableStateMapOf<String, String>()

    fun updateAuto(v: Boolean) { auto = v; prefs.edit().putBoolean("auto", v).apply() }
    fun updateTheme(v: String) { theme = v; prefs.edit().putString("theme", v).apply() }
    fun updateAutoGroup(v: String) { autoGroup = v; prefs.edit().putString("autoGroup", v).apply() }

    fun select(s: Server) {
        selected = s
        prefs.edit().putString("sel", s.link).apply()
    }

    fun loadGroup(g: Group, force: Boolean = false) {
        if (g.repo == null) return
        val key = "g:" + g.id
        if (key in loading) return
        if (!force && groupSubs.containsKey(g.id)) return
        viewModelScope.launch {
            loading.add(key); groupError.remove(g.id)
            try { groupSubs[g.id] = repo.discover(g, force) }
            catch (e: Exception) { groupError[g.id] = "Не удалось получить список: ${e.message}" }
            loading.remove(key)
        }
    }

    fun load(sg: Subgroup, force: Boolean = false) {
        if (sg.id in loading) return
        if (!force && servers.containsKey(sg.id)) return
        viewModelScope.launch {
            loading.add(sg.id); error = null
            try { servers[sg.id] = repo.load(sg, force) }
            catch (e: Exception) { error = "Не удалось загрузить: ${e.message}" }
            loading.remove(sg.id)
        }
    }

    fun pingAll(sg: Subgroup) {
        val list = servers[sg.id] ?: return
        viewModelScope.launch {
            val sem = Semaphore(8)
            list.take(120).map { s ->
                async(Dispatchers.IO) { sem.withPermit { pings[s.link] = repo.delay(s) ?: -1 } }
            }.awaitAll()
        }
    }

    fun toggle(onStart: (Server) -> Unit, onStop: () -> Unit) {
        if (busy) return
        if (VpnState.running) { onStop(); return }
        viewModelScope.launch {
            busy = true
            VpnState.message = null
            var target = selected
            if (auto) {
                searching = true
                val t = try { Auto.fastest(getApplication(), autoGroup) } catch (e: Exception) { null }
                searching = false
                if (t == null) {
                    VpnState.message = "Рабочих серверов не найдено — попробуйте другую группу"
                    busy = false
                    return@launch
                }
                target = t
                select(t)
            }
            val t = target
            if (t == null) VpnState.message = "Выберите сервер в «Библиотеке»"
            else { VpnState.message = "Подключение…"; onStart(t) }
            busy = false
        }
    }
}
