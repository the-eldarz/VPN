package app.fastvpn

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = Repo(app)
    private val prefs = app.getSharedPreferences("s", 0)

    var auto by mutableStateOf(prefs.getBoolean("auto", false)); private set
    var selected by mutableStateOf(prefs.getString("sel", null)?.let { Parser.parseOne(it) }); private set
    var selectedSg by mutableStateOf(prefs.getString("sg", null)); private set
    var connected by mutableStateOf(false); private set
    var busy by mutableStateOf(false); private set
    var status by mutableStateOf("Не подключено"); private set
    var error by mutableStateOf<String?>(null); private set

    val servers = mutableStateMapOf<String, List<Server>>()
    val loading = mutableStateListOf<String>()
    val pings = mutableStateMapOf<String, Int>()

    private fun save() {
        prefs.edit().putBoolean("auto", auto).putString("sel", selected?.link).putString("sg", selectedSg).apply()
    }

    fun setAuto(v: Boolean) { auto = v; save() }

    fun select(s: Server, sg: Subgroup) {
        selected = s; selectedSg = sg.id; save()
    }

    fun load(sg: Subgroup, force: Boolean = false) {
        if (sg.id in loading) return
        if (!force && servers.containsKey(sg.id)) return
        viewModelScope.launch {
            loading.add(sg.id); error = null
            try { servers[sg.id] = repo.load(sg, force) }
            catch (e: Exception) { error = "Не удалось загрузить: ${e.message}" }
            loading.remove(sg.id)
        }
    }

    fun pingAll(sg: Subgroup) {
        val list = servers[sg.id] ?: return
        viewModelScope.launch {
            val sem = Semaphore(40)
            list.take(300).map { s ->
                async(Dispatchers.IO) { sem.withPermit { pings[s.link] = repo.ping(s) ?: -1 } }
            }.awaitAll()
        }
    }

    fun toggle() {
        if (busy) return
        if (connected) { connected = false; status = "Не подключено"; return }
        viewModelScope.launch {
            busy = true
            var target = selected
            if (auto) {
                status = "Ищем самый быстрый сервер…"
                val sg = Catalog.groups.flatMap { it.subgroups }.firstOrNull { it.id == selectedSg }
                    ?: Catalog.groups[0].subgroups[0]
                try {
                    val list = servers[sg.id] ?: repo.load(sg).also { servers[sg.id] = it }
                    repo.fastest(list)?.let { target = it; selected = it; selectedSg = sg.id; save() }
                } catch (e: Exception) { }
            }
            if (target == null) {
                status = "Выберите сервер в «Библиотеке»"
            } else {
                connected = true
                status = "Тестовый режим: ядро VPN ещё не подключено"
            }
            busy = false
        }
    }
}
