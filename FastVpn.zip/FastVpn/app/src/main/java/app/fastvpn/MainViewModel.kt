package app.fastvpn

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit

data class SubStat(val tested: Int, val total: Int, val ok: Int, val best: Int?, val done: Boolean)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = Repo(app)
    private val prefs = app.getSharedPreferences("s", 0)

    var auto by mutableStateOf(prefs.getBoolean("auto", false)); private set
    var theme by mutableStateOf(prefs.getString("theme", "system") ?: "system"); private set
    var autoGroup by mutableStateOf(prefs.getString("autoGroup", "all") ?: "all"); private set
    var selected by mutableStateOf(prefs.getString("sel", null)?.let { Parser.parseOne(it) }); private set
    var busy by mutableStateOf(false); private set
    var searching by mutableStateOf(false); private set
    var error by mutableStateOf<String?>(null); private set

    val connected: Boolean get() = VpnState.running
    val status: String
        get() = when {
            VpnState.running -> "Подключено"
            searching -> "Ищем самый быстрый сервер…"
            else -> VpnState.message ?: "Не подключено"
        }

    val servers = mutableStateMapOf<String, List<Server>>()
    val loading = mutableStateListOf<String>()
    val pings = mutableStateMapOf<String, Int>()
    val subStats = mutableStateMapOf<String, SubStat>()
    val testing = mutableStateListOf<String>()
    val groupSubs = mutableStateMapOf<String, List<Subgroup>>()
    val groupError = mutableStateMapOf<String, String>()

    fun updateAuto(v: Boolean) { auto = v; prefs.edit().putBoolean("auto", v).apply() }
    fun updateTheme(v: String) { theme = v; prefs.edit().putString("theme", v).apply() }
    fun updateAutoGroup(v: String) { autoGroup = v; prefs.edit().putString("autoGroup", v).apply() }

    fun select(s: Server) {
        selected = s
        prefs.edit().putString("sel", s.link).apply()
    }

    fun loadGroup(g: Group, force: Boolean = false) {
        if (g.repo == null) return
        val key = "g:" + g.id
        if (key in loading) return
        if (!force && groupSubs.containsKey(g.id)) return
        viewModelScope.launch {
            loading.add(key); groupError.remove(g.id)
            try { groupSubs[g.id] = repo.discover(g, force) }
            catch (e: Exception) { groupError[g.id] = "Не удалось получить список: ${e.message}" }
            loading.remove(key)
        }
    }

    fun load(sg: Subgroup, force: Boolean = false) {
        if (sg.id in loading) return
        if (!force && servers.containsKey(sg.id)) return
        viewModelScope.launch {
            loading.add(sg.id); error = null
            try { servers[sg.id] = repo.load(sg, force) }
            catch (e: Exception) { error = "Не удалось загрузить: ${e.message}" }
            loading.remove(sg.id)
        }
    }

    /** Проверяет серверы подгруппы реальным запросом через прокси (первые 120). refresh = заново скачать список. */
    fun testSubgroup(sg: Subgroup, refresh: Boolean) {
        if (sg.id in testing) return
        testing.add(sg.id)
        viewModelScope.launch {
            try {
                val list = repo.load(sg, refresh)
                servers[sg.id] = list
                val sample = list.take(120)
                subStats[sg.id] = SubStat(0, sample.size, 0, null, sample.isEmpty())
                var tested = 0
                var ok = 0
                var best: Int? = null
                val lock = Mutex()
                val sem = Semaphore(8)
                sample.map { s ->
                    async(Dispatchers.IO) {
                        sem.withPermit {
                            val d = repo.delay(s)
                            pings[s.link] = d ?: -1
                            lock.withLock {
                                tested++
                                if (d != null) {
                                    ok++
                                    val b = best
                                    if (b == null || d < b) best = d
                                }
                                subStats[sg.id] = SubStat(tested, sample.size, ok, best, tested == sample.size)
                            }
                        }
                    }
                }.awaitAll()
            } catch (e: Exception) {
                error = "Не удалось проверить: ${e.message}"
            }
            testing.remove(sg.id)
        }
    }

    fun toggle(onStart: (Server) -> Unit, onStop: () -> Unit) {
        if (busy) return
        if (VpnState.running) { onStop(); return }
        viewModelScope.launch {
            busy = true
            VpnState.message = null
            var target = selected
            if (auto) {
                searching = true
                val t = try { Auto.fastest(getApplication(), autoGroup) } catch (e: Exception) { null }
                searching = false
                if (t == null) {
                    VpnState.message = "Рабочих серверов не найдено — попробуйте другую группу"
                    busy = false
                    return@launch
                }
                target = t
                select(t)
            }
            val t = target
            if (t == null) VpnState.message = "Выберите сервер в «Библиотеке»"
            else { VpnState.message = "Подключение…"; onStart(t) }
            busy = false
        }
    }
}
