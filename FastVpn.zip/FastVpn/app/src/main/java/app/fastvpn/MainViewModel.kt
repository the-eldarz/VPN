package app.fastvpn

import android.app.Application
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit

data class SubStat(val tested: Int, val total: Int, val ok: Int, val best: Int?, val done: Boolean)
data class AppEntry(val label: String, val pkg: String, val icon: ImageBitmap?)

private fun Drawable.toImage(size: Int): ImageBitmap {
    val b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val c = Canvas(b)
    setBounds(0, 0, size, size)
    draw(c)
    return b.asImageBitmap()
}

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = Repo(app)
    private val prefs = app.getSharedPreferences("s", 0)

    var auto by mutableStateOf(prefs.getBoolean("auto", false)); private set
    var theme by mutableStateOf(prefs.getString("theme", "system") ?: "system"); private set
    var autoGroup by mutableStateOf(prefs.getString("autoGroup", "all") ?: "all"); private set
    var autoReconnect by mutableStateOf(prefs.getBoolean("autoReconnect", true)); private set
    var killSwitch by mutableStateOf(prefs.getBoolean("killSwitch", false)); private set
    var splitMode by mutableStateOf(prefs.getString("splitMode", "all") ?: "all"); private set
    var splitApps by mutableStateOf<Set<String>>(prefs.getStringSet("splitApps", emptySet()) ?: emptySet()); private set
    var refreshHours by mutableStateOf(prefs.getInt("refreshHours", 6)); private set
    var refreshWifiOnly by mutableStateOf(prefs.getBoolean("refreshWifiOnly", true)); private set
    var lastRefresh by mutableStateOf(prefs.getLong("lastRefresh", 0L)); private set
    var refreshing by mutableStateOf(false); private set
    var selected by mutableStateOf(prefs.getString("sel", null)?.let { Parser.parseOne(it) }); private set
    var busy by mutableStateOf(false); private set
    var searching by mutableStateOf(false); private set
    var error by mutableStateOf<String?>(null); private set
    var apps by mutableStateOf<List<AppEntry>?>(null); private set

    // сервис может сам сменить выбранный сервер (автопереподключение)
    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "sel") selected = prefs.getString("sel", null)?.let { Parser.parseOne(it) }
    }

    init { prefs.registerOnSharedPreferenceChangeListener(prefListener) }

    override fun onCleared() { prefs.unregisterOnSharedPreferenceChangeListener(prefListener) }

    val connected: Boolean get() = VpnState.running
    val status: String
        get() = when {
            VpnState.running -> "Подключено"
            searching -> "Ищем самый быстрый сервер…"
            else -> VpnState.message ?: "Не подключено"
        }

    val servers = mutableStateMapOf<String, List<Server>>()
    val loading = mutableStateListOf<String>()
    val pings = mutableStateMapOf<String, Int>()
    val subStats = mutableStateMapOf<String, SubStat>()
    val testing = mutableStateListOf<String>()
    val groupSubs = mutableStateMapOf<String, List<Subgroup>>()
    val groupError = mutableStateMapOf<String, String>()
    val favorites = mutableStateListOf<Server>().apply { addAll(Favorites.load(app)) }

    // ---------------------------------------------------------------- настройки

    fun updateAuto(v: Boolean) { auto = v; prefs.edit().putBoolean("auto", v).apply() }
    fun updateTheme(v: String) { theme = v; prefs.edit().putString("theme", v).apply() }
    fun updateAutoGroup(v: String) { autoGroup = v; prefs.edit().putString("autoGroup", v).apply() }
    fun updateAutoReconnect(v: Boolean) { autoReconnect = v; prefs.edit().putBoolean("autoReconnect", v).apply() }
    fun updateKillSwitch(v: Boolean) { killSwitch = v; prefs.edit().putBoolean("killSwitch", v).apply() }
    fun updateSplitMode(v: String) { splitMode = v; prefs.edit().putString("splitMode", v).apply() }

    fun toggleApp(pkg: String) {
        val s = splitApps.toMutableSet()
        if (!s.add(pkg)) s.remove(pkg)
        splitApps = s
        prefs.edit().putStringSet("splitApps", HashSet(s)).apply()
    }

    fun updateRefreshHours(h: Int) {
        refreshHours = h
        prefs.edit().putInt("refreshHours", h).apply()
        Refresh.schedule(getApplication())
    }

    fun updateRefreshWifi(v: Boolean) {
        refreshWifiOnly = v
        prefs.edit().putBoolean("refreshWifiOnly", v).apply()
        Refresh.schedule(getApplication())
    }

    fun refreshNow() {
        if (refreshing) return
        refreshing = true
        viewModelScope.launch {
            try {
                Refresh.run(getApplication()) { false }
                lastRefresh = prefs.getLong("lastRefresh", 0L)
                servers.clear()
            } catch (_: Exception) { }
            refreshing = false
        }
    }

    fun loadApps() {
        if (apps != null) return
        viewModelScope.launch(Dispatchers.IO) {
            val a = getApplication<Application>()
            val pm = a.packageManager
            val list = pm.getInstalledApplications(0)
                .filter { it.packageName != a.packageName && pm.getLaunchIntentForPackage(it.packageName) != null }
                .map { ai ->
                    AppEntry(ai.loadLabel(pm).toString(), ai.packageName, runCatching { ai.loadIcon(pm).toImage(64) }.getOrNull())
                }
                .sortedBy { it.label.lowercase() }
            apps = list
        }
    }

    // ---------------------------------------------------------------- избранное

    fun isFavorite(s: Server) = favorites.any { it.link == s.link }

    fun toggleFavorite(s: Server) {
        val i = favorites.indexOfFirst { it.link == s.link }
        if (i >= 0) favorites.removeAt(i) else favorites.add(s)
        Favorites.save(getApplication(), favorites)
    }

    // ---------------------------------------------------------------- серверы

    fun select(s: Server) {
        selected = s
        prefs.edit().putString("sel", s.link).apply()
    }

    fun loadGroup(g: Group, force: Boolean = false) {
        if (g.repo == null) return
        val key = "g:" + g.id
        if (key in loading) return
        if (!force && groupSubs.containsKey(g.id)) return
        viewModelScope.launch {
            loading.add(key); groupError.remove(g.id)
            try { groupSubs[g.id] = repo.discover(g, force) }
            catch (e: Exception) { groupError[g.id] = "Не удалось получить список: ${e.message}" }
            loading.remove(key)
        }
    }

    fun load(sg: Subgroup, force: Boolean = false) {
        if (sg.id in loading) return
        if (!force && servers.containsKey(sg.id)) return
        viewModelScope.launch {
            loading.add(sg.id); error = null
            try { servers[sg.id] = repo.load(sg, force) }
            catch (e: Exception) { error = "Не удалось загрузить: ${e.message}" }
            loading.remove(sg.id)
        }
    }

    /** Проверяет серверы подгруппы реальным запросом через прокси (первые 120). refresh = заново скачать список. */
    fun testSubgroup(sg: Subgroup, refresh: Boolean) =
        runTest(sg.id) { repo.load(sg, refresh).also { servers[sg.id] = it } }

    fun testFavorites() = runTest("favorites") { favorites.toList() }

    private fun runTest(key: String, getList: suspend () -> List<Server>) {
        if (key in testing) return
        testing.add(key)
        viewModelScope.launch {
            try {
                val sample = getList().take(120)
                subStats[key] = SubStat(0, sample.size, 0, null, sample.isEmpty())
                var tested = 0
                var ok = 0
                var best: Int? = null
                val lock = Mutex()
                val sem = Semaphore(8)
                sample.map { s ->
                    async(Dispatchers.IO) {
                        sem.withPermit {
                            val d = repo.delay(s)
                            pings[s.link] = d ?: -1
                            lock.withLock {
                                tested++
                                if (d != null) {
                                    ok++
                                    val b = best
                                    if (b == null || d < b) best = d
                                }
                                subStats[key] = SubStat(tested, sample.size, ok, best, tested == sample.size)
                            }
                        }
                    }
                }.awaitAll()
            } catch (e: Exception) {
                error = "Не удалось проверить: ${e.message}"
            }
            testing.remove(key)
        }
    }

    fun toggle(onStart: (Server) -> Unit, onStop: () -> Unit) {
        if (busy) return
        if (VpnState.running) { onStop(); return }
        viewModelScope.launch {
            busy = true
            VpnState.message = null
            var target = selected
            if (auto) {
                searching = true
                val t = try { Auto.fastest(getApplication(), autoGroup) } catch (e: Exception) { null }
                searching = false
                if (t == null) {
                    VpnState.message = "Рабочих серверов не найдено — попробуйте другую группу"
                    busy = false
                    return@launch
                }
                target = t
                select(t)
            }
            val t = target
            if (t == null) VpnState.message = "Выберите сервер в «Библиотеке»"
            else { VpnState.message = "Подключение…"; onStart(t) }
            busy = false
        }
    }
}
