package app.fastvpn

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL

class Repo(private val ctx: Context) {
    suspend fun load(sg: Subgroup, force: Boolean = false): List<Server> = withContext(Dispatchers.IO) {
        val f = File(ctx.filesDir, "sub_${sg.id}.txt")
        if (force || !f.exists()) {
            try { f.writeText(download(sg.url)) } catch (e: Exception) { if (!f.exists()) throw e }
        }
        Parser.parseAll(f.readText())
    }

    private fun download(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10_000
        c.readTimeout = 20_000
        try { return c.inputStream.bufferedReader().readText() } finally { c.disconnect() }
    }

    /** TCP-пинг до сервера в мс, null если недоступен. */
    suspend fun ping(s: Server): Int? = withContext(Dispatchers.IO) {
        try {
            val t = System.nanoTime()
            Socket().use { it.connect(InetSocketAddress(s.host, s.port), 2500) }
            ((System.nanoTime() - t) / 1_000_000).toInt()
        } catch (e: Exception) { null }
    }

    suspend fun fastest(list: List<Server>): Server? = coroutineScope {
        val sem = Semaphore(40)
        list.shuffled().take(80).map { s ->
            async(Dispatchers.IO) { sem.withPermit { ping(s)?.let { s to it } } }
        }.awaitAll().filterNotNull().minByOrNull { it.second }?.first
    }
}
