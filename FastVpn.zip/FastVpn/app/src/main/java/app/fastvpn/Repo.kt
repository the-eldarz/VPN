package app.fastvpn

import android.content.Context
import android.net.Uri
import androidx.compose.runtime.mutableStateMapOf
import org.json.JSONArray
import org.json.JSONObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL

object Diag {
    /** Причина последней неудачной проверки сервера (по ссылке). */
    val errors = mutableStateMapOf<String, String>()

    fun reason(e: Throwable): String {
        val m = e.message ?: e.javaClass.simpleName
        val last = m.substringAfterLast(" > ").trim()
        val l = last.lowercase()
        return when {
            "timeout" in l || "deadline" in l -> "таймаут"
            "refused" in l -> "отказ в соединении"
            "reset" in l -> "соединение сброшено"
            "eof" in l -> "обрыв соединения"
            "certificate" in l || "tls" in l -> "ошибка TLS"
            else -> last.take(80)
        }
    }
}

class Repo(private val ctx: Context) {
    suspend fun load(sg: Subgroup, force: Boolean = false): List<Server> = withContext(Dispatchers.IO) {
        val f = File(ctx.filesDir, "sub_${sg.id}.txt")
        if (force || !f.exists()) {
            try { f.writeText(download(sg.url)) } catch (e: Exception) { if (!f.exists()) throw e }
        }
        Parser.parseAll(f.readText())
    }

    private fun download(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10_000
        c.readTimeout = 20_000
        c.setRequestProperty("User-Agent", "FastVpn")
        try { return c.inputStream.bufferedReader().readText() } finally { c.disconnect() }
    }

    private val skip = listOf(
        "readme", "license", "requirements", "robots", "base64", "qr-code", "qr_code",
        "tor-bridge", "tor_bridge", "changelog", "/.github"
    )

    /** Находит .txt-подписки в репозитории группы через GitHub API (кэшируется). */
    suspend fun discover(g: Group, force: Boolean = false): List<Subgroup> = withContext(Dispatchers.IO) {
        val repo = g.repo ?: return@withContext emptyList()
        val f = File(ctx.filesDir, "tree_${g.id}.json")
        if (force || !f.exists()) {
            try { f.writeText(fetchTree(repo)) } catch (e: Exception) { if (!f.exists()) throw e }
        }
        val o = JSONObject(f.readText())
        val branch = o.getString("branch")
        val arr = o.getJSONArray("files")
        val out = ArrayList<Subgroup>()
        for (i in 0 until arr.length()) {
            val p = arr.getJSONArray(i).getString(0)
            val size = arr.getJSONArray(i).getLong(1)
            val lp = p.lowercase()
            if (size <= 0 || size > 30_000_000 || skip.any { lp.contains(it) }) continue
            out.add(Subgroup(
                g.id + "_" + Integer.toHexString(p.hashCode()),
                p.replace(Regex("\\.(txt|list|sub)$", RegexOption.IGNORE_CASE), ""),
                "${size / 1024} КБ",
                "https://raw.githubusercontent.com/$repo/$branch/" + Uri.encode(p, "/")
            ))
        }
        out.sortedBy { it.title.lowercase() }.take(300)
    }

    private fun fetchTree(repo: String): String {
        val info = JSONObject(download("https://api.github.com/repos/$repo"))
        val branch = info.getString("default_branch")
        val tree = JSONObject(download("https://api.github.com/repos/$repo/git/trees/$branch?recursive=1")).getJSONArray("tree")
        val files = JSONArray()
        for (i in 0 until tree.length()) {
            val t = tree.getJSONObject(i)
            if (t.getString("type") != "blob") continue
            val p = t.getString("path")
            if (!(p.endsWith(".txt", true) || p.endsWith(".list", true) || p.endsWith(".sub", true))) continue
            files.put(JSONArray().put(p).put(t.optLong("size")))
        }
        return JSONObject().put("branch", branch).put("files", files).toString()
    }

    /** TCP-пинг до сервера в мс, null если недоступен. */
    suspend fun ping(s: Server): Int? = withContext(Dispatchers.IO) {
        try {
            val t = System.nanoTime()
            Socket().use { it.connect(InetSocketAddress(s.host, s.port), 2500) }
            ((System.nanoTime() - t) / 1_000_000).toInt()
        } catch (e: Exception) { null }
    }

    /** Реальная проверка: запрос через прокси-сервер. Возвращает мс или null, если сервер не работает. */
    suspend fun delay(s: Server): Int? = withContext(Dispatchers.IO) {
        try {
            val ms = fastcore.Fastcore.measure(
                XrayConfig.build(s.link, true), "https://www.gstatic.com/generate_204", 7L
            ).toInt()
            Diag.errors.remove(s.link)
            ms
        } catch (e: Throwable) {
            Diag.errors[s.link] = Diag.reason(e)
            null
        }
    }

    /** Самый быстрый из списка по реальной проверке: сервер и его задержка в мс. */
    suspend fun fastestPick(list: List<Server>): Pair<Server, Int>? = coroutineScope {
        val sem = Semaphore(12)
        list.distinctBy { it.link }.map { s ->
            async(Dispatchers.IO) { sem.withPermit { delay(s)?.let { s to it } } }
        }.awaitAll().filterNotNull().minByOrNull { it.second }
    }
}
