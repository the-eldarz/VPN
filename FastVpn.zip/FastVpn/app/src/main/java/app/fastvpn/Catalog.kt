package app.fastvpn

data class Subgroup(val id: String, val title: String, val desc: String, val url: String)

/** repo != null: список файлов-подписок находится автоматически через GitHub API. */
data class Group(
    val id: String, val title: String, val author: String,
    val subgroups: List<Subgroup> = emptyList(), val repo: String? = null
)
data class Server(val link: String, val name: String, val host: String, val port: Int)

object Catalog {
    private const val FLAT = "https://raw.githubusercontent.com/FLAT447/v2ray-lists/main/sources/output/"
    private const val RJ = "https://raw.githubusercontent.com/whoahaow/rjsxrd/main/githubmirror/bypass/"
    private const val IGA = "https://raw.githubusercontent.com/igareck/vpn-configs-for-russia/main/"

    val groups = listOf(
        Group(
            "igareck", "igareck", "github.com/igareck/vpn-configs-for-russia",
            listOf(
                Subgroup("iga_bl_mobile", "BLACK mobile (ТОП-150)", "Чёрные списки, лёгкая для телефона", IGA + "BLACK_VLESS_RUS_mobile.txt"),
                Subgroup("iga_bl_vless", "BLACK VLESS", "Чёрные списки, VLESS, полная", IGA + "BLACK_VLESS_RUS.txt"),
                Subgroup("iga_bl_ss", "BLACK SS+All", "Чёрные списки: SS, Hysteria2, VMess, Trojan", IGA + "BLACK_SS%2BAll_RUS.txt"),
                Subgroup("iga_bl_weak", "BLACK SS weak DPI", "Shadowsocks для сетей со слабым DPI", IGA + "BLACK_SS_WEAK_DPI_RUS.txt"),
                Subgroup("iga_wh_mobile", "WHITE mobile (ТОП-150)", "Белые списки, лёгкая для телефона", IGA + "Vless-Reality-White-Lists-Rus-Mobile.txt"),
                Subgroup("iga_wh_cidr", "WHITE CIDR полная", "Белые списки, все CIDR", IGA + "WHITE-CIDR-RU-all.txt"),
                Subgroup("iga_wh_checked", "WHITE CIDR (VK, Яндекс…)", "Белые списки: VK, Yandex, CDNVideo, Beeline", IGA + "WHITE-CIDR-RU-checked.txt"),
                Subgroup("iga_wh_sni", "WHITE SNI", "Белые списки, SNI", IGA + "WHITE-SNI-RU-all.txt"),
            )
        ),
        Group(
            "rjsxrd", "rjsxrd", "github.com/whoahaow/rjsxrd",
            listOf(
                Subgroup("rj_1", "bypass-1", "Обход белых списков, ~286 серверов", RJ + "bypass-1.txt"),
                Subgroup("rj_2", "bypass-2", "Обход белых списков, ~262 сервера", RJ + "bypass-2.txt"),
                Subgroup("rj_3", "bypass-3", "Обход белых списков, ~277 серверов", RJ + "bypass-3.txt"),
                Subgroup("rj_4", "bypass-4", "Обход белых списков, ~281 сервер", RJ + "bypass-4.txt"),
                Subgroup("rj_5", "bypass-5", "Обход белых списков, ~25 серверов", RJ + "bypass-5.txt"),
                Subgroup("rj_6", "bypass-6", "Обход белых списков, ~279 серверов", RJ + "bypass-6.txt"),
                Subgroup("rj_all", "bypass-all (все сразу)", "~621 сервер, на телефоне лучше файлы по отдельности", RJ + "bypass-all.txt"),
            ),
            repo = "whoahaow/rjsxrd"
        ),
        Group(
            "flat447", "FLAT447", "github.com/FLAT447/v2ray-lists",
            listOf(
                Subgroup("white_full", "WHITE FULL", "Список WHITE, полный", FLAT + "WHITE_FULL.txt"),
                Subgroup("white_lite", "WHITE LITE", "Список WHITE, облегчённый", FLAT + "WHITE_LITE.txt"),
                Subgroup("black_full", "BLACK FULL", "Список BLACK, полный", FLAT + "BLACK_FULL.txt"),
                Subgroup("black_lte", "BLACK LITE", "Список BLACK, облегчённый", FLAT + "BLACK_LTE.txt"),
            )
        ),
        Group("nullcore", "NullCoreDeveloper", "github.com/NullCoreDeveloper/v2whitelist", repo = "NullCoreDeveloper/v2whitelist"),
        Group("antidpi", "igareck anti-dpi", "github.com/igareck/anti-dpi-for-russia", repo = "igareck/anti-dpi-for-russia"),
        Group("gribi", "histeenn", "github.com/histeenn/VLESS-PO-GRIBI", repo = "histeenn/VLESS-PO-GRIBI"),
        Group("jsxta", "jsxta", "github.com/jsxta/whitelist-russia", repo = "jsxta/whitelist-russia"),
        Group("luxxuria", "luxxuria", "github.com/luxxuria/harvester", repo = "luxxuria/harvester"),
    )
}
