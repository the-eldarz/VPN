package app.fastvpn

data class Subgroup(val id: String, val title: String, val desc: String, val url: String)
data class Group(val id: String, val title: String, val author: String, val subgroups: List<Subgroup>)
data class Server(val link: String, val name: String, val host: String, val port: Int)

object Catalog {
    private const val B = "https://raw.githubusercontent.com/FLAT447/v2ray-lists/main/sources/output/"
    val groups = listOf(
        Group(
            "flat447", "FLAT447", "github.com/FLAT447/v2ray-lists",
            listOf(
                Subgroup("white_full", "WHITE FULL", "Список WHITE, полный", B + "WHITE_FULL.txt"),
                Subgroup("white_lite", "WHITE LITE", "Список WHITE, облегчённый", B + "WHITE_LITE.txt"),
                Subgroup("black_full", "BLACK FULL", "Список BLACK, полный", B + "BLACK_FULL.txt"),
                Subgroup("black_lte", "BLACK LITE", "Список BLACK, облегчённый", B + "BLACK_LTE.txt"),
            )
        )
    )
}
