package app.fastvpn

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Refresh.schedule(this)
        setContent { Root() }
    }
}

@Composable
fun Root(vm: MainViewModel = viewModel()) {
    val dark = when (vm.theme) { "dark" -> true; "light" -> false; else -> isSystemInDarkTheme() }
    val flash = remember { Animatable(0f) }
    LaunchedEffect(vm.connected) {
        if (vm.connected) {
            flash.snapTo(0f)
            flash.animateTo(0.32f, tween(220))
            flash.animateTo(0f, tween(900))
        }
    }
    MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Box(Modifier.fillMaxSize()) {
                App(vm)
                // зелёная вспышка по всему экрану при подключении
                Box(Modifier.fillMaxSize().graphicsLayer { alpha = flash.value }.background(Color(0xFF2E7D32)))
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun App(vm: MainViewModel) {
    val pager = rememberPagerState { Catalog.groups.size + 1 }
    val ctx = LocalContext.current
    var pending by remember { mutableStateOf<String?>(null) }
    val vpnLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val l = pending; pending = null
        if (r.resultCode == Activity.RESULT_OK && l != null) FastVpnService.start(ctx, l)
        else VpnState.message = "Разрешение VPN не выдано"
    }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val onStart: (Server) -> Unit = { s ->
        if (Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        val i = VpnService.prepare(ctx)
        if (i != null) { pending = s.link; vpnLauncher.launch(i) } else FastVpnService.start(ctx, s.link)
    }
    val onStop: () -> Unit = { FastVpnService.stop(ctx) }

    var tab by remember { mutableIntStateOf(0) }
    var open by remember { mutableStateOf<Subgroup?>(null) }
    BackHandler(enabled = tab == 1 && open != null) { open = null }
    Scaffold(bottomBar = {
        NavigationBar {
            NavigationBarItem(selected = tab == 0, onClick = { tab = 0 },
                icon = { Icon(Icons.Default.Home, null) }, label = { Text("Главный") })
            NavigationBarItem(selected = tab == 1, onClick = { tab = 1 },
                icon = { Icon(Icons.AutoMirrored.Filled.List, null) }, label = { Text("Библиотека") })
            NavigationBarItem(selected = tab == 2, onClick = { tab = 2 },
                icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Настройки") })
        }
    }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            val o = open
            when {
                tab == 0 -> Home(vm, onStart, onStop)
                tab == 2 -> SettingsScreen(vm)
                o == null -> Library(vm, pager) { open = it }
                else -> SubgroupScreen(vm, o) { open = null }
            }
        }
    }
}
