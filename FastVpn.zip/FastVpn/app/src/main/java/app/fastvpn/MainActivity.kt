package app.fastvpn

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.os.SystemClock
import android.net.TrafficStats
import kotlinx.coroutines.delay
import androidx.compose.material.icons.filled.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.ui.graphics.graphicsLayer
import kotlinx.coroutines.launch
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { Root() }
    }
}

@Composable
fun Root(vm: MainViewModel = viewModel()) {
    val dark = when (vm.theme) { "dark" -> true; "light" -> false; else -> isSystemInDarkTheme() }
    val flash = remember { Animatable(0f) }
    LaunchedEffect(vm.connected) {
        if (vm.connected) {
            flash.snapTo(0f)
            flash.animateTo(0.32f, tween(220))
            flash.animateTo(0f, tween(900))
        }
    }
    MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Box(Modifier.fillMaxSize()) {
                App(vm)
                // зелёная вспышка по всему экрану при подключении
                Box(Modifier.fillMaxSize().graphicsLayer { alpha = flash.value }.background(Color(0xFF2E7D32)))
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun App(vm: MainViewModel) {
    val pager = rememberPagerState { Catalog.groups.size }
    val ctx = LocalContext.current
    var pending by remember { mutableStateOf<String?>(null) }
    val vpnLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val l = pending; pending = null
        if (r.resultCode == Activity.RESULT_OK && l != null) FastVpnService.start(ctx, l)
        else VpnState.message = "Разрешение VPN не выдано"
    }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val onStart: (Server) -> Unit = { s ->
        if (Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        val i = VpnService.prepare(ctx)
        if (i != null) { pending = s.link; vpnLauncher.launch(i) } else FastVpnService.start(ctx, s.link)
    }
    val onStop: () -> Unit = { FastVpnService.stop(ctx) }
    var tab by remember { mutableIntStateOf(0) }
    var open by remember { mutableStateOf<Subgroup?>(null) }
    BackHandler(enabled = tab == 1 && open != null) { open = null }
    Scaffold(bottomBar = {
        NavigationBar {
            NavigationBarItem(selected = tab == 0, onClick = { tab = 0 },
                icon = { Icon(Icons.Default.Home, null) }, label = { Text("Главный") })
            NavigationBarItem(selected = tab == 1, onClick = { tab = 1 },
                icon = { Icon(Icons.AutoMirrored.Filled.List, null) }, label = { Text("Библиотека") })
            NavigationBarItem(selected = tab == 2, onClick = { tab = 2 },
                icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Настройки") })
        }
    }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            val o = open
            when {
                tab == 0 -> Home(vm, onStart, onStop)
                tab == 2 -> SettingsScreen(vm)
                o == null -> Library(vm, pager) { open = it }
                else -> SubgroupScreen(vm, o) { open = null }
            }
        }
    }
}

@Composable
fun Home(vm: MainViewModel, onStart: (Server) -> Unit, onStop: () -> Unit) {
    val connecting = vm.busy || vm.searching ||
        (!vm.connected && (VpnState.message == "Подключение…" || VpnState.message == "Подбор сервера…"))
    val state = if (vm.connected) 2 else if (connecting) 1 else 0
    val green = Color(0xFF2E7D32)
    val container by animateColorAsState(
        if (state == 2) green else MaterialTheme.colorScheme.primary, tween(600), label = "container"
    )
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val pressScale by animateFloatAsState(if (pressed) 0.93f else 1f, tween(120), label = "press")
    val stateScale by animateFloatAsState(
        if (state == 2) 1.05f else 1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy), label = "state"
    )
    val inf = rememberInfiniteTransition(label = "rings")
    val ring by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1600, easing = LinearEasing), RepeatMode.Restart), label = "ring")

    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(vm.selected?.name ?: "Сервер не выбран", style = MaterialTheme.typography.titleMedium,
            maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
        Spacer(Modifier.height(16.dp))
        Box(Modifier.size(280.dp), contentAlignment = Alignment.Center) {
            if (state != 0) {
                repeat(2) { i ->
                    Box(
                        Modifier.size(200.dp)
                            .graphicsLayer {
                                val t = (ring + i * 0.5f) % 1f
                                scaleX = 1f + 0.45f * t
                                scaleY = 1f + 0.45f * t
                                alpha = (1f - t) * (if (state == 2) 0.22f else 0.45f)
                            }
                            .background(container, CircleShape)
                    )
                }
            }
            Button(
                onClick = { vm.toggle(onStart, onStop) },
                modifier = Modifier.size(200.dp).graphicsLayer {
                    scaleX = pressScale * stateScale
                    scaleY = pressScale * stateScale
                },
                shape = CircleShape,
                interactionSource = src,
                colors = ButtonDefaults.buttonColors(
                    containerColor = container,
                    contentColor = if (state == 2) Color.White else MaterialTheme.colorScheme.onPrimary
                )
            ) {
                Crossfade(targetState = state, label = "label") { st ->
                    when (st) {
                        1 -> CircularProgressIndicator(Modifier.size(48.dp), color = Color.White)
                        2 -> Text("СТОП", fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        else -> Text("СТАРТ", fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Crossfade(targetState = vm.status, label = "status") { Text(it, textAlign = TextAlign.Center) }
        AnimatedVisibility(visible = vm.connected) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Spacer(Modifier.height(8.dp))
                SessionInfo()
            }
        }
        Spacer(Modifier.height(32.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Автоподключение к самому быстрому", Modifier.weight(1f))
            Switch(checked = vm.auto, onCheckedChange = { vm.updateAuto(it) })
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Library(vm: MainViewModel, pager: PagerState, onOpen: (Subgroup) -> Unit) {
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize()) {
        ScrollableTabRow(selectedTabIndex = pager.currentPage, edgePadding = 8.dp) {
            Catalog.groups.forEachIndexed { i, g ->
                Tab(
                    selected = pager.currentPage == i,
                    onClick = { scope.launch { pager.animateScrollToPage(i) } },
                    text = { Text(g.title, maxLines = 1) }
                )
            }
        }
        HorizontalPager(state = pager, modifier = Modifier.fillMaxSize()) { page ->
            GroupPage(vm, Catalog.groups[page], onOpen)
        }
    }
}

@Composable
fun GroupPage(vm: MainViewModel, g: Group, onOpen: (Subgroup) -> Unit) {
    LaunchedEffect(g.id) { vm.loadGroup(g) }
    val subs = (g.subgroups + vm.groupSubs[g.id].orEmpty()).distinctBy { it.url }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item { Text(g.author, style = MaterialTheme.typography.bodySmall) }
        items(subs, key = { it.id }) { sg -> SubRow(vm, sg, onOpen) }
        item {
            if (("g:" + g.id) in vm.loading) LinearProgressIndicator(Modifier.fillMaxWidth())
            vm.groupError[g.id]?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            if (g.repo != null && vm.groupSubs.containsKey(g.id) && subs.isEmpty()) {
                Text("В репозитории нет подходящих .txt-файлов с подписками")
            }
        }
        if (g.repo != null) {
            item { TextButton(onClick = { vm.loadGroup(g, true) }) { Text("Обновить список файлов") } }
        }
    }
}

@Composable
fun SubRow(vm: MainViewModel, sg: Subgroup, onOpen: (Subgroup) -> Unit) {
    val st = vm.subStats[sg.id]
    val busy = sg.id in vm.testing
    Card(Modifier.fillMaxWidth().clickable { onOpen(sg) }) {
        ListItem(
            headlineContent = { Text(sg.title, maxLines = 2, overflow = TextOverflow.Ellipsis) },
            supportingContent = {
                Text(
                    when {
                        st == null -> sg.desc
                        !st.done -> "Проверка… ${st.tested}/${st.total} · работает ${st.ok}"
                        else -> "Работает ${st.ok} из ${st.total}" + (st.best?.let { " · лучший $it мс" } ?: "")
                    }
                )
            },
            trailingContent = {
                IconButton(onClick = { vm.testSubgroup(sg, true) }, enabled = !busy) {
                    if (busy) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                    else Icon(Icons.Default.Refresh, "Проверить пинг")
                }
            },
            colors = ListItemDefaults.colors(containerColor = Color.Transparent)
        )
    }
}

@Composable
fun SubgroupScreen(vm: MainViewModel, sg: Subgroup, onBack: () -> Unit) {
    LaunchedEffect(sg.id) { vm.load(sg) }
    val raw = vm.servers[sg.id].orEmpty()
    val done = vm.subStats[sg.id]?.done == true
    val list = remember(raw, done) {
        if (!done) raw
        else raw.sortedWith(
            compareBy<Server> { val p = vm.pings[it.link]; if (p == null) 1 else if (p < 0) 2 else 0 }
                .thenBy { vm.pings[it.link] ?: 0 }
        )
    }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) }
            Text(sg.title, Modifier.weight(1f), style = MaterialTheme.typography.titleLarge)
            TextButton(onClick = { vm.load(sg, true) }) { Text("Обновить") }
            TextButton(onClick = { vm.testSubgroup(sg, false) }, enabled = sg.id !in vm.testing) { Text("Пинг") }
        }
        if (sg.id in vm.loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        vm.error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(16.dp)) }
        Text("Серверов: ${list.size}", Modifier.padding(horizontal = 16.dp))
        LazyColumn {
            items(list, key = { it.link }) { s ->
                val p = vm.pings[s.link]
                val err = if (p != null && p < 0) Diag.errors[s.link] else null
                ListItem(
                    headlineContent = { Text(s.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    supportingContent = { Text("${s.host}:${s.port}" + (err?.let { " · $it" } ?: ""), maxLines = 2) },
                    trailingContent = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (p != null) Text(if (p < 0) "—" else "$p мс")
                            if (vm.selected?.link == s.link) Icon(Icons.Default.Check, null)
                        }
                    },
                    modifier = Modifier.clickable { vm.select(s) }
                )
            }
        }
    }
}

@Composable
fun SessionInfo() {
    var now by remember { mutableLongStateOf(SystemClock.elapsedRealtime()) }
    LaunchedEffect(Unit) { while (true) { now = SystemClock.elapsedRealtime(); delay(1000) } }
    val uid = Process.myUid()
    val rx = TrafficStats.getUidRxBytes(uid) - VpnState.baseRx
    val tx = TrafficStats.getUidTxBytes(uid) - VpnState.baseTx
    Text(
        "${fmtTime(now - VpnState.sessionStart)}  ·  ↓ ${fmtBytes(rx)}  ↑ ${fmtBytes(tx)}",
        style = MaterialTheme.typography.bodyMedium
    )
}

@Composable
fun RadioRow(text: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = onClick)
        Text(text)
    }
}

@Composable
fun SettingsScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    val totals = remember(tick, vm.connected) { Stats.totals(ctx) }
    val days = remember(tick, vm.connected) { Stats.days(ctx, 7) }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        item { Text("Тема", style = MaterialTheme.typography.titleMedium) }
        item { RadioRow("Системная (по умолчанию)", vm.theme == "system") { vm.updateTheme("system") } }
        item { RadioRow("Тёмная", vm.theme == "dark") { vm.updateTheme("dark") } }
        item { RadioRow("Светлая", vm.theme == "light") { vm.updateTheme("light") } }

        item { Spacer(Modifier.height(12.dp)) }
        item { Text("Автоподключение: откуда брать серверы", style = MaterialTheme.typography.titleMedium) }
        item {
            Text(
                "Если переключатель на главном экране включён, приложение проверит серверы " +
                    "из выбранного источника и подключится к самому быстрому.",
                style = MaterialTheme.typography.bodySmall
            )
        }
        item { RadioRow("Все группы", vm.autoGroup == "all") { vm.updateAutoGroup("all") } }
        items(Catalog.groups, key = { it.id }) { g ->
            RadioRow(g.title, vm.autoGroup == g.id) { vm.updateAutoGroup(g.id) }
        }

        item { Spacer(Modifier.height(12.dp)) }
        item { Text("Статистика", style = MaterialTheme.typography.titleMedium) }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Подключений: ${totals.sessions}")
                    Text("Время в VPN: ${fmtTime(totals.ms)}")
                    Text("Скачано: ${fmtBytes(totals.rx)}")
                    Text("Отправлено: ${fmtBytes(totals.tx)}")
                }
            }
        }
        item { Text("Последние 7 дней", style = MaterialTheme.typography.titleSmall) }
        items(days) { d ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(d.day)
                Text("${fmtTime(d.ms)} · ↓ ${fmtBytes(d.rx)} ↑ ${fmtBytes(d.tx)}")
            }
        }
        item {
            Text(
                "Трафик считается по данным системы для приложения и включает шифрование, поэтому он приблизительный.",
                style = MaterialTheme.typography.bodySmall
            )
        }
        item { TextButton(onClick = { Stats.reset(ctx); tick++ }) { Text("Сбросить статистику") } }
    }
}
