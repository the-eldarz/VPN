package app.fastvpn

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { App() } }
    }
}

@Composable
fun App(vm: MainViewModel = viewModel()) {
    val ctx = LocalContext.current
    var pending by remember { mutableStateOf<String?>(null) }
    val vpnLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val l = pending; pending = null
        if (r.resultCode == Activity.RESULT_OK && l != null) FastVpnService.start(ctx, l)
        else VpnState.message = "Разрешение VPN не выдано"
    }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val onStart: (Server) -> Unit = { s ->
        if (Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        val i = VpnService.prepare(ctx)
        if (i != null) { pending = s.link; vpnLauncher.launch(i) } else FastVpnService.start(ctx, s.link)
    }
    val onStop: () -> Unit = { FastVpnService.stop(ctx) }
    var tab by remember { mutableIntStateOf(0) }
    var open by remember { mutableStateOf<Subgroup?>(null) }
    BackHandler(enabled = tab == 1 && open != null) { open = null }
    Scaffold(bottomBar = {
        NavigationBar {
            NavigationBarItem(selected = tab == 0, onClick = { tab = 0 },
                icon = { Icon(Icons.Default.Home, null) }, label = { Text("Главный") })
            NavigationBarItem(selected = tab == 1, onClick = { tab = 1 },
                icon = { Icon(Icons.AutoMirrored.Filled.List, null) }, label = { Text("Библиотека") })
        }
    }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            val o = open
            when {
                tab == 0 -> Home(vm, onStart, onStop)
                o == null -> Library { open = it }
                else -> SubgroupScreen(vm, o) { open = null }
            }
        }
    }
}

@Composable
fun Home(vm: MainViewModel, onStart: (Server) -> Unit, onStop: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(vm.selected?.name ?: "Сервер не выбран", style = MaterialTheme.typography.titleMedium,
            maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
        Spacer(Modifier.height(32.dp))
        Button(
            onClick = { vm.toggle(onStart, onStop) }, modifier = Modifier.size(200.dp), shape = CircleShape,
            colors = ButtonDefaults.buttonColors(
                containerColor = if (vm.connected) Color(0xFF2E7D32) else MaterialTheme.colorScheme.primary)
        ) {
            if (vm.busy) CircularProgressIndicator(color = Color.White)
            else Text(if (vm.connected) "СТОП" else "СТАРТ", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(24.dp))
        Text(vm.status, textAlign = TextAlign.Center)
        Spacer(Modifier.height(32.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Автоподключение к самому быстрому", Modifier.weight(1f))
            Switch(checked = vm.auto, onCheckedChange = { vm.updateAuto(it) })
        }
    }
}

@Composable
fun Library(onOpen: (Subgroup) -> Unit) {
    LazyColumn(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(Catalog.groups, key = { it.id }) { g ->
            var exp by remember { mutableStateOf(true) }
            Card(Modifier.fillMaxWidth()) {
                Column {
                    ListItem(
                        headlineContent = { Text(g.title, fontWeight = FontWeight.Bold) },
                        supportingContent = { Text(g.author) },
                        trailingContent = {
                            Icon(if (exp) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown, null)
                        },
                        modifier = Modifier.clickable { exp = !exp }
                    )
                    if (exp) g.subgroups.forEach { sg ->
                        ListItem(
                            headlineContent = { Text(sg.title) },
                            supportingContent = { Text(sg.desc) },
                            modifier = Modifier.clickable { onOpen(sg) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SubgroupScreen(vm: MainViewModel, sg: Subgroup, onBack: () -> Unit) {
    LaunchedEffect(sg.id) { vm.load(sg) }
    val list = vm.servers[sg.id].orEmpty()
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) }
            Text(sg.title, Modifier.weight(1f), style = MaterialTheme.typography.titleLarge)
            TextButton(onClick = { vm.load(sg, true) }) { Text("Обновить") }
            TextButton(onClick = { vm.pingAll(sg) }) { Text("Пинг") }
        }
        if (sg.id in vm.loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        vm.error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(16.dp)) }
        Text("Серверов: ${list.size}", Modifier.padding(horizontal = 16.dp))
        LazyColumn {
            items(list, key = { it.link }) { s ->
                val p = vm.pings[s.link]
                ListItem(
                    headlineContent = { Text(s.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    supportingContent = { Text("${s.host}:${s.port}", maxLines = 1) },
                    trailingContent = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (p != null) Text(if (p < 0) "—" else "$p мс")
                            if (vm.selected?.link == s.link) Icon(Icons.Default.Check, null)
                        }
                    },
                    modifier = Modifier.clickable { vm.select(s, sg) }
                )
            }
        }
    }
}
